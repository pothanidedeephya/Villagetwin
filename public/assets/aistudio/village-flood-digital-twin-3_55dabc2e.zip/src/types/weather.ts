export interface CurrentWeather {
  temperature_c: number;
  condition: string;
  conditionCode?: string;
  humidity_percent: number;
  windSpeed_kmh: number;
  windDirection?: string;
  rainfall_mmh: number; // Current / past hour precipitation rate
  precipitation_today_mm?: number;
  pressure_hpa?: number;
  cloudCover_percent?: number;
}

export interface WeatherForecastHour {
  time: string; // ISO or formatted '14:00'
  temperature_c: number;
  condition: string;
  rainfall_mm: number;
  rainProbability_percent?: number;
  windSpeed_kmh: number;
}

export interface WeatherForecastDay {
  date: string; // '2026-10-19'
  dayName: string; // 'Monday'
  maxTemp_c: number;
  minTemp_c: number;
  condition: string;
  totalRainfall_mm: number;
  rainProbability_percent?: number;
}

export interface WeatherData {
  villageName: string;
  coordinates: [number, number]; // [lng, lat]
  current: CurrentWeather;
  hourlyForecast: WeatherForecastHour[];
  dailyForecast: WeatherForecastDay[];
  provider: string;
  isLiveApiKey: boolean;
  providerKeyName?: string;
  lastUpdated: string;
  sourceAttribution: string;
  notice?: string;
}
