import type { FeatureCollection, Polygon } from 'geojson';

export type HazardType =
  | 'flood'
  | 'waterlogging'
  | 'cyclone'
  | 'tsunami'
  | 'earthquake'
  | 'landslide'
  | 'drought'
  | 'heatwave'
  | 'wildfire';

export type RiskLevel = 'low' | 'moderate' | 'high' | 'very_high';

export interface HazardEventRecord {
  year: string;
  eventName: string;
  impact: string;
  observedMagnitude?: string;
}

export interface HazardDataProvenance {
  source: string;
  publicationYear: string;
  spatialResolution: string;
  scientificAssumptions: string;
  confidenceLevel: 'High' | 'Moderate' | 'Indicative';
}

export interface HazardAssessment {
  hazardType: HazardType;
  title: string;
  subtitle: string;
  riskLevel: RiskLevel;
  scientificScore: number; // 0 - 100
  isGeographicallyApplicable: boolean;
  applicabilityRationale: string;
  primaryMetricLabel: string;
  primaryMetricValue: string;
  exposedPopulation: number;
  isDemographicDataAvailable?: boolean;
  demographicNote?: string;
  exposedRoadsKm: number;
  isRoadsDataAvailable?: boolean;
  roadsNote?: string;
  exposedFarmlandHa: number;
  criticalFacilitiesExposed: Array<{
    name: string;
    type: string;
    vulnerabilityNote: string;
  }>;
  historicalEvents: HazardEventRecord[];
  provenance: HazardDataProvenance;
  preparednessActions: string[];
  mitigationRecommendations: string[];
  riskPolygons: FeatureCollection<Polygon, {
    hazardType: HazardType;
    riskLevel: RiskLevel;
    zoneName: string;
    description: string;
    intensityLabel: string;
  }>;
}

export interface MultiHazardSummary {
  villageName: string;
  district: string;
  mandal: string;
  compositeRiskScore: number; // 0 - 100
  highestRiskHazards: HazardType[];
  totalVulnerablePopulation: number;
  priorityActions: string[];
  assessments: Record<HazardType, HazardAssessment>;
}
