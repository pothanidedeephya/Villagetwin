import React, { useState, useEffect, useRef } from 'react';
import {
  Waves,
  Building2,
  AlertTriangle,
  Play,
  Menu,
  X,
  Compass,
  Loader2,
  Sliders,
  Droplets,
  FileCode,
  FileText,
  ShieldCheck,
  ChevronRight,
  Info,
  Upload,
  CheckCircle,
  Database,
  Sparkles,
  Wrench,
  Search,
  Activity,
  Wind,
  CloudRain,
  Mountain,
  Sun,
  Flame,
  Globe,
  MapPin,
  Layers,
  CloudSun,
  RefreshCw,
} from 'lucide-react';

import type {
  ScenarioType,
  SimulationConfig,
  SimulationResult,
  VillageDataset,
  DrainageProperties,
  RetentionPondProperties,
} from './types/village';
import type { FeatureCollection, LineString, Polygon } from 'geojson';
import type { HazardAssessment, HazardType, MultiHazardSummary } from './types/hazard';
import type { InfrastructureIntervention } from './types/infrastructure';
import type {
  LocationSearchResult,
  RealLocationGeospatialData,
  InfrastructureCandidateSite,
} from './types/nationwide';

import { DEMO_VILLAGE, shiftVillageDataset } from './data/demoVillage';
import { NATIONWIDE_BENCHMARK_LOCATIONS } from './data/indiaLocations';
import { defaultSimulationEngine } from './services/simulationService';
import { generateNationwideHazardAssessment } from './services/indiaHazardEngine';
import {
  fetchLocationGeospatialData,
  generateCandidateInfrastructureSites,
} from './services/geospatialService';
import { getInitialInfrastructureInterventions } from './services/infrastructureService';

// Component Views
import { VillageMap, VillageMapCameraAction } from './components/map/VillageMap';
import { DrainagePlanningView } from './components/drainage/DrainagePlanningView';
import { ImpactAssessmentView } from './components/impact/ImpactAssessmentView';
import { DataManagementView } from './components/data/DataManagementView';
import { AboutModelView } from './components/about/AboutModelView';

// Modals
import { NationwideLocationSearch } from './components/search/NationwideLocationSearch';
import { MultiHazardDashboardModal } from './components/hazard/MultiHazardDashboardModal';
import { SmartInfrastructurePlannerModal } from './components/infrastructure/SmartInfrastructurePlannerModal';
import { CandidateInfrastructureModal } from './components/infrastructure/CandidateInfrastructureModal';
import { AiAdvisoryModal } from './components/ai/AiAdvisoryModal';
import { DataCoverageReportModal } from './components/coverage/DataCoverageReportModal';
import { SimulationSettingsModal } from './components/simulation/SimulationSettingsModal';
import { EarthquakeMonitorModal } from './components/earthquake/EarthquakeMonitorModal';
import type { EarthquakeEvent } from './types/earthquake';
import { fetchLiveEarthquakes } from './services/earthquakeService';
import type { WeatherData } from './types/weather';
import { fetchVillageWeather } from './services/weatherService';
import { VillageWeatherWidget } from './components/weather/VillageWeatherWidget';

export default function App() {
  // Active view: 'main' is the primary digital twin map screen
  const [activeView, setActiveView] = useState<'main' | 'drainage' | 'impact' | 'data' | 'about'>('main');

  // Currently selected location across India (Default: Kotturu Benchmark)
  const [currentLocation, setCurrentLocation] = useState<LocationSearchResult>(
    NATIONWIDE_BENCHMARK_LOCATIONS[0]
  );

  // Active geospatial dataset for current location
  const [geospatialData, setGeospatialData] = useState<RealLocationGeospatialData | null>(null);
  const [isLoadingGeoData, setIsLoadingGeoData] = useState(false);

  // Active hazard filter for map and analysis
  const [activeHazard, setActiveHazard] = useState<HazardType>('flood');

  // Multi-Hazard summary calculated dynamically for current location
  const [hazardSummary, setHazardSummary] = useState<MultiHazardSummary>(() =>
    generateNationwideHazardAssessment(NATIONWIDE_BENCHMARK_LOCATIONS[0])
  );

  // Candidate infrastructure sites calculated for current location
  const [candidateSites, setCandidateSites] = useState<InfrastructureCandidateSite[]>(() =>
    generateCandidateInfrastructureSites(NATIONWIDE_BENCHMARK_LOCATIONS[0])
  );

  // Smart infrastructure interventions catalog
  const [interventions, setInterventions] = useState<InfrastructureIntervention[]>(() =>
    getInitialInfrastructureInterventions(DEMO_VILLAGE)
  );

  // Modals state
  const [showHazardModal, setShowHazardModal] = useState(false);
  const [showInfraModal, setShowInfraModal] = useState(false);
  const [showCandidatesModal, setShowCandidatesModal] = useState(false);
  const [showAiModal, setShowAiModal] = useState(false);
  const [showCoverageModal, setShowCoverageModal] = useState(false);
  const [showSimSettingsModal, setShowSimSettingsModal] = useState(false);
  const [showEarthquakeModal, setShowEarthquakeModal] = useState(false);
  const [earthquakes, setEarthquakes] = useState<EarthquakeEvent[]>([]);
  const [selectedEarthquake, setSelectedEarthquake] = useState<EarthquakeEvent | null>(null);
  const [showMenu, setShowMenu] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Request tracking refs to eliminate race conditions when rapidly changing villages
  const locationReqIdRef = useRef<number>(0);
  const weatherReqIdRef = useRef<number>(0);
  const eqReqIdRef = useRef<number>(0);

  // Live weather state for currently selected village
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [isLoadingWeather, setIsLoadingWeather] = useState(false);
  const [weatherError, setWeatherError] = useState<string | null>(null);

  // Simulation execution feedback notification
  const [simFeedback, setSimFeedback] = useState<{
    title: string;
    detail: string;
    type: 'success' | 'error';
  } | null>(null);

  // Basemap switch: 'roadmap' vs 'satellite'
  const [mapType, setMapType] = useState<'roadmap' | 'satellite'>('roadmap');

  // Camera action trigger for Fit Village and Locate Assets
  const [cameraAction, setCameraAction] = useState<VillageMapCameraAction | undefined>(undefined);

  // Village Dataset for map and hydraulic engine
  const [dataset, setDataset] = useState<VillageDataset>(DEMO_VILLAGE);

  // Proposed infrastructure overrides
  const [proposedDrains, setProposedDrains] = useState<FeatureCollection<LineString, DrainageProperties>>(
    DEMO_VILLAGE.drainageLines
  );
  const [proposedPonds, setProposedPonds] = useState<FeatureCollection<Polygon, RetentionPondProperties>>(
    DEMO_VILLAGE.retentionPonds
  );

  const [selectedFeature, setSelectedFeature] = useState<any | null>(null);
  const [quotaExceeded, setQuotaExceeded] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);

  // Simulation parameters
  const [simConfig, setSimConfig] = useState<SimulationConfig>({
    scenario: 'existing_drainage',
    rainfallIntensity_mmh: 65,
    rainfallDuration_hours: 4,
    soilType: 'black_cotton',
    infiltrationRate_mmh: 6.0,
    runoffCoefficient: 0.65,
    tideOutfallCondition: 'normal',
    desiltingFactor: 0.65,
    timeStep_mins: 60,
  });

  // Simulation result state
  const [latestResult, setLatestResult] = useState<SimulationResult>(() => ({
    scenario: 'existing_drainage',
    config: {
      scenario: 'existing_drainage',
      rainfallIntensity_mmh: 65,
      rainfallDuration_hours: 4,
      soilType: 'black_cotton',
      infiltrationRate_mmh: 6.0,
      runoffCoefficient: 0.65,
      tideOutfallCondition: 'normal',
      desiltingFactor: 0.65,
      timeStep_mins: 60,
    },
    frames: [
      {
        hour: 2,
        rainfallThisHour_mm: 65,
        cumulativeRain_mm: 120,
        runoffVolume_m3: 45000,
        drainedVolume_m3: 15000,
        inundatedArea_ha: 8.4,
        maxDepth_m: 0.62,
        floodedBuildingsCount: 0,
        criticalFacilitiesFlooded: [],
        affectedRoadsKm: 1.45,
        floodPolygons: { type: 'FeatureCollection', features: [] },
      },
    ],
    peakHour: 0,
    totalRainfall_mm: 180,
    maxInundatedArea_ha: 8.4,
    peakDepth_m: 0.62,
    affectedBuildings: [],
    affectedRoads: DEMO_VILLAGE.roads.features.map((r) => ({
      id: r.properties.id,
      name: r.properties.name,
      depth_m: r.properties.elevation_m < 4.8 ? 0.3 : 0,
      impassable: r.properties.elevation_m < 4.8,
    })),
    farmlandInundated_ha: 6.8,
    vulnerablePopulationAffected: 0,
    estimatedLoss_lakhs: 0,
    drainageEfficiency_percent: 32,
    isIllustrative: true,
    modelLabel: 'Illustrative Rational-Depression Solver (Unvalidated Demo)',
  }));

  // Google Maps Quota notification listener
  useEffect(() => {
    const handler = () => setQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handler);
    return () => window.removeEventListener('gmp-quota-exceeded', handler);
  }, []);

  // When selected location changes: load real geospatial data, hazards, candidates, and camera
  useEffect(() => {
    let isMounted = true;
    const currentReqId = ++locationReqIdRef.current;
    setIsLoadingGeoData(true);

    async function loadData() {
      // 1. Calculate dynamic multi-hazard summary for new location
      const hazards = generateNationwideHazardAssessment(currentLocation);
      if (isMounted && locationReqIdRef.current === currentReqId) {
        setHazardSummary(hazards);
        // Persist calculated multi-hazard risk assessments to database
        try {
          Object.entries(hazards.assessments).forEach(([hType, detail]) => {
            fetch('/api/risk-assessments', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                locationId: currentLocation.id,
                hazardType: hType,
                riskLevel: detail.riskLevel,
                scientificScore: detail.scientificScore,
                primaryMetricLabel: detail.primaryMetricLabel,
                primaryMetricValue: detail.primaryMetricValue,
                exposedPopulation: detail.exposedPopulation,
                exposedRoadsKm: detail.exposedRoadsKm,
                exposedFarmlandHa: detail.exposedFarmlandHa,
                confidenceTier: detail.provenance?.confidenceLevel || 'Indicative',
                provenanceSource: detail.provenance?.source || 'National Hazard Atlases',
                assessment_summary: `${detail.title} in ${currentLocation.displayName}: evaluated as ${detail.riskLevel.toUpperCase()} risk based on ${detail.provenance?.source || 'National Hazard Atlases'}.`,
              }),
            }).catch(() => {});
          });
        } catch (e) {}
      }

      // 2. Calculate candidate infrastructure sites
      const candidates = generateCandidateInfrastructureSites(currentLocation);
      if (isMounted && locationReqIdRef.current === currentReqId) {
        setCandidateSites(candidates);
      }

      // 3. Fetch real geospatial data
      const geo = await fetchLocationGeospatialData(currentLocation);
      if (!isMounted || locationReqIdRef.current !== currentReqId) return;

      setGeospatialData(geo);

      // 4. Update the active village dataset for maps and simulation
      // If Kotturu benchmark, use full demo twin. If another village, use its real properties and geometry.
      const isDemoVillage = currentLocation.id === 'loc-ap-kothuru';
      const updatedDataset: VillageDataset = isDemoVillage
        ? {
            ...DEMO_VILLAGE,
            villageName: currentLocation.name,
            district: currentLocation.district,
            mandal: currentLocation.subdistrict || currentLocation.district,
            state: currentLocation.state,
            center: currentLocation.center,
            elevation_m: currentLocation.elevation_m || 4.2,
            totalPopulation: currentLocation.population || DEMO_VILLAGE.totalPopulation,
            boundary: geo.boundary,
            roads: geo.roads,
            waterBodies: geo.waterBodies,
            buildings: geo.buildings.features.length > 0 ? geo.buildings : DEMO_VILLAGE.buildings,
          }
        : {
            villageName: currentLocation.name,
            district: currentLocation.district,
            mandal: currentLocation.subdistrict || currentLocation.district,
            state: currentLocation.state,
            center: currentLocation.center,
            elevation_m: currentLocation.elevation_m || 25,
            totalPopulation: currentLocation.population || 0,
            boundary: geo.boundary,
            roads: geo.roads,
            waterBodies: geo.waterBodies,
            buildings: geo.buildings, // Empty unless verified (No fake markers)
            drainageLines: { type: 'FeatureCollection', features: [] },
            retentionPonds: { type: 'FeatureCollection', features: [] },
          };

      setDataset(updatedDataset);
      setProposedDrains(updatedDataset.drainageLines);
      setProposedPonds(updatedDataset.retentionPonds);
      setInterventions(getInitialInfrastructureInterventions(updatedDataset));

      // 5. Calibrate hydrological simulation configuration to village terrain
      const isHilly = (currentLocation.elevation_m || 25) > 500 ||
        ['meghalaya', 'uttarakhand', 'himachal', 'kerala'].some((s) => (currentLocation.state || '').toLowerCase().includes(s));
      const locationConfig: SimulationConfig = {
        scenario: 'existing_drainage',
        rainfallIntensity_mmh: isHilly ? 80 : 65,
        rainfallDuration_hours: 4,
        soilType: isHilly ? 'red_sandy_loam' : 'black_cotton',
        infiltrationRate_mmh: isHilly ? 12.0 : 6.0,
        runoffCoefficient: isHilly ? 0.72 : 0.65,
        tideOutfallCondition: 'normal',
        desiltingFactor: 0.65,
        timeStep_mins: 60,
      };
      setSimConfig(locationConfig);

      // 6. Recalculate simulation results immediately for new location with location-specific inputs
      const initResult = await defaultSimulationEngine.runSimulation(updatedDataset, locationConfig);
      if (isMounted && locationReqIdRef.current === currentReqId) {
        setLatestResult(initResult);
      }

      // Trigger map camera pan & fit
      setCameraAction({ type: 'recenter', timestamp: Date.now() });
      setIsLoadingGeoData(false);
    }

    loadData();
    return () => {
      isMounted = false;
    };
  }, [currentLocation]);

  // Weather integration: Automatically retrieve real-time weather for current village coordinates
  const refreshWeather = async () => {
    if (!currentLocation?.center) return;
    const wReqId = ++weatherReqIdRef.current;
    setIsLoadingWeather(true);
    setWeatherError(null);
    try {
      const [lng, lat] = currentLocation.center;
      const data = await fetchVillageWeather(lat, lng, currentLocation.name);
      if (weatherReqIdRef.current === wReqId) {
        setWeatherData(data);
      }
    } catch (err: any) {
      console.warn('Weather retrieval error:', err);
      if (weatherReqIdRef.current === wReqId) {
        setWeatherError(err?.message || 'Weather service temporarily unavailable');
      }
    } finally {
      if (weatherReqIdRef.current === wReqId) {
        setIsLoadingWeather(false);
      }
    }
  };

  useEffect(() => {
    refreshWeather();
  }, [currentLocation]);

  // Fetch real USGS earthquake events relative to currently selected village
  useEffect(() => {
    if (!currentLocation?.center) return;
    const currentEqReqId = ++eqReqIdRef.current;
    const [lng, lat] = currentLocation.center;
    fetchLiveEarthquakes({
      timeRange: 'week',
      minMag: 2.5,
      lat,
      lng,
      maxDistanceKm: 2500,
      sortBy: 'distance',
      limit: 100,
    })
      .then((data) => {
        if (eqReqIdRef.current === currentEqReqId && data.events) {
          setEarthquakes(data.events);
        }
      })
      .catch((err) => {
        console.warn('Real earthquake feed error:', err);
      });
  }, [currentLocation]);

  const handleApplyWeatherRainfall = (rainfall_mmh: number) => {
    const intensity = Math.max(1, Math.round(rainfall_mmh));
    const newConfig: SimulationConfig = {
      ...simConfig,
      rainfallIntensity_mmh: intensity,
    };
    setSimConfig(newConfig);
    runFullSimulation(newConfig);
    setSimFeedback({
      title: 'Weather Rainfall Applied to Simulation',
      detail: `Precipitation input updated to ${intensity} mm/h from ${weatherData?.provider || 'live meteorological'} data. Illustrative flood model recalculated.`,
      type: 'success',
    });
  };


  const runFullSimulation = async (configToRun: SimulationConfig) => {
    if (isSimulating) return; // Prevent duplicate concurrent submissions
    setIsSimulating(true);
    try {
      const activeDataset: VillageDataset = {
        ...dataset,
        drainageLines: proposedDrains,
        retentionPonds: proposedPonds,
      };

      const result = await defaultSimulationEngine.runSimulation(activeDataset, configToRun);
      setLatestResult(result);

      // Persist genuine simulation run execution and calculated outputs to database
      try {
        fetch('/api/simulations/run', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            locationId: currentLocation.id,
            hazardType: 'flood',
            scenarioParameters: configToRun,
            status: 'completed',
            modelName: 'BharatTwin-Hydrology-2D',
            modelVersion: 'v2.1',
            inputDataSources: ['OpenStreetMap Building Vectors', 'Terrain DEM', 'Panchayat Drainage Layer'],
            resultSummary: {
              maxInundatedArea_ha: result.maxInundatedArea_ha,
              peakDepth_m: result.peakDepth_m,
              waterloggedBuildingsCount: result.affectedBuildings?.length || 0,
              vulnerableRoadLength_km: result.affectedRoads?.length || 0,
              farmlandInundated_ha: result.farmlandInundated_ha,
              vulnerablePopulationAffected: result.vulnerablePopulationAffected,
              scenarioLabel: result.scenario,
            },
          }),
        }).catch((dbErr) => console.warn('Simulation database save note:', dbErr));
      } catch (e) {}

      // Visible confirmation toast
      setSimFeedback({
        title: `Simulation Completed (${result.timestamp || 'Just now'})`,
        detail: `${result.scenario.replace('_', ' ').toUpperCase()}: ${result.config.rainfallIntensity_mmh} mm/h rain · Inundated: ${result.maxInundatedArea_ha} ha · Peak Depth: ${result.peakDepth_m}m.`,
        type: 'success',
      });

      // Auto-dismiss after 6 seconds
      setTimeout(() => {
        setSimFeedback((prev) => (prev?.type === 'success' ? null : prev));
      }, 6000);
    } catch (err) {
      console.error('Simulation execution failed:', err);

      // Persist failed simulation run accurately
      try {
        fetch('/api/simulations/run', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            locationId: currentLocation.id,
            hazardType: 'flood',
            scenarioParameters: configToRun,
            status: 'failed',
            errorMessage: err instanceof Error ? err.message : 'Hydrological calculation failure',
          }),
        }).catch(() => {});
      } catch (e) {}

      setSimFeedback({
        title: 'Simulation Execution Error',
        detail: err instanceof Error ? err.message : 'Hydrological calculation failed. Please retry.',
        type: 'error',
      });
    } finally {
      setIsSimulating(false);
    }
  };

  const toggleIntervention = (id: string) => {
    setInterventions((prev) =>
      prev.map((item) => (item.id === id ? { ...item, isEnabled: !item.isEnabled } : item))
    );
  };

  const handleLocateCandidate = (candidate: InfrastructureCandidateSite) => {
    setSelectedFeature({
      category: 'smart_intervention',
      properties: {
        name: candidate.title,
        estimatedCostLakhs: candidate.estimatedCostLakhs,
        populationProtected: candidate.expectedBeneficiaries,
        riskReductionPercent: candidate.suitabilityScore - 20,
        description: candidate.justification,
        technicalSpecs: `Evidence: ${candidate.evidenceDatasets.join(', ')}`,
      },
      coordinates: candidate.candidateCoordinates,
    });
    setCameraAction({ type: 'recenter', timestamp: Date.now() });
  };

  // Active hazard polygons to render on the map
  const activeHazardPolygons = hazardSummary.assessments[activeHazard]?.riskPolygons;

  const currentHazardDetail = hazardSummary.assessments[activeHazard];
  const coverageReport = geospatialData?.coverage;

  const hazardTabs: Array<{ type: HazardType; label: string }> = [
    { type: 'flood', label: 'Flood' },
    { type: 'waterlogging', label: 'Waterlogging' },
    { type: 'cyclone', label: 'Cyclone' },
    { type: 'earthquake', label: 'Earthquake' },
    { type: 'tsunami', label: 'Tsunami' },
    { type: 'landslide', label: 'Landslide' },
    { type: 'drought', label: 'Drought' },
    { type: 'heatwave', label: 'Heatwave' },
  ];

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-50 text-slate-800 font-sans overflow-hidden">
      
      {/* 1. Header Strip */}
      <header className="h-14 bg-white border-b border-slate-200 px-3 sm:px-5 flex items-center justify-between shrink-0 z-30 gap-3">
        {/* Brand */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-xs">
            <Globe className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight leading-none flex items-center gap-1.5">
              <span>Bharat Village Twin</span>
              <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded bg-blue-50 text-blue-700 border border-blue-200">
                All-India
              </span>
            </h1>
            <p className="text-[10px] text-slate-500 mt-0.5 hidden md:block">
              Nationwide Multi-Hazard Digital Twin & AI Infrastructure Planning
            </p>
          </div>
        </div>

        {/* Nationwide Location Search Bar & Compact Weather */}
        <div className="flex-1 max-w-2xl mx-2 flex items-center gap-2">
          <div className="flex-1 min-w-0">
            <NationwideLocationSearch
              currentLocation={currentLocation}
              onSelectLocation={setCurrentLocation}
              isLoadingData={isLoadingGeoData}
            />
          </div>

          {/* Compact Weather Summary Pill near Village Search */}
          {weatherData ? (
            <div
              className="hidden lg:flex items-center gap-2 px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 shrink-0"
              title={`Weather in ${weatherData.villageName} (${weatherData.provider}): ${weatherData.current.condition}, ${weatherData.current.temperature_c}°C, Humidity ${weatherData.current.humidity_percent}%, Rain ${weatherData.current.rainfall_mmh} mm/h`}
            >
              <CloudSun className="w-3.5 h-3.5 text-blue-700 shrink-0" />
              <span className="font-bold text-slate-900">{weatherData.current.temperature_c}°C</span>
              <span className="text-slate-300">|</span>
              <span className="text-slate-600 truncate max-w-[85px]">{weatherData.current.condition}</span>
              <span className="text-slate-300">|</span>
              <span className="font-mono text-blue-700 text-[11px] font-medium">
                {weatherData.current.rainfall_mmh} mm/h
              </span>
              <button
                onClick={refreshWeather}
                disabled={isLoadingWeather}
                className="p-0.5 hover:text-slate-900 text-slate-400 cursor-pointer transition-colors"
                title="Refresh Weather"
              >
                <RefreshCw className={`w-3 h-3 ${isLoadingWeather ? 'animate-spin text-blue-600' : ''}`} />
              </button>
            </div>
          ) : isLoadingWeather ? (
            <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-500 shrink-0">
              <RefreshCw className="w-3 h-3 animate-spin text-blue-600" />
              <span>Weather...</span>
            </div>
          ) : null}
        </div>

        {/* Header Action Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            onClick={() => setShowEarthquakeModal(true)}
            className="px-2.5 sm:px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            title="Real-Time USGS Earthquake Hazards Monitor"
          >
            <Activity className="w-3.5 h-3.5 text-rose-600 animate-pulse" />
            <span className="hidden sm:inline">Earthquakes</span>
            {earthquakes.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[10px] font-bold">
                {earthquakes.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setShowAiModal(true)}
            className="px-2.5 sm:px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">AI Advisor</span>
          </button>

          <button
            onClick={() => setShowMenu(true)}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            title="All Planning Tools & Data Management"
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Layout: Left Sidebar (Hazard Selector) & Right Main Content Area */}
      <div className="flex-1 flex min-h-0 overflow-hidden relative">

        {/* Left Sidebar: Multi-Hazard Selector & Weather Panel */}
        <aside
          className={`fixed inset-y-0 left-0 top-14 z-40 w-60 sm:w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 md:static md:translate-x-0 shrink-0 ${
            isMobileSidebarOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full md:translate-x-0'
          }`}
        >
          {/* Professional Sidebar Header */}
          <div className="px-3.5 py-3 border-b border-slate-200 flex items-center justify-between bg-slate-50/70 shrink-0">
            <div>
              <h2 className="text-xs font-bold text-slate-900 tracking-wide uppercase">Hazard Selector</h2>
              <p className="text-[10px] text-slate-500 mt-0.5">National Multi-Hazard Atlas</p>
            </div>
            {/* Mobile Close Button */}
            <button
              onClick={() => setIsMobileSidebarOpen(false)}
              className="md:hidden p-1 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Clean Vertical Hazard Buttons List */}
          <div className="flex-1 p-2 space-y-1 overflow-y-auto">
            {hazardTabs.map((tab) => {
              const isSelected = activeHazard === tab.type;
              const level = hazardSummary.assessments[tab.type]?.riskLevel;
              return (
                <button
                  key={tab.type}
                  onClick={() => {
                    setActiveHazard(tab.type);
                    setIsMobileSidebarOpen(false);
                  }}
                  className={`w-full px-3 py-2 rounded-lg text-xs flex items-center justify-between transition-colors border text-left cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600 text-white border-blue-600 font-semibold shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50 hover:text-slate-900 hover:border-slate-300 font-medium'
                  }`}
                >
                  <span className="truncate">{tab.label}</span>
                  <span
                    className={`text-[10px] font-medium tracking-wide uppercase px-1.5 py-0.5 rounded shrink-0 ml-1.5 ${
                      isSelected
                        ? 'bg-blue-700 text-blue-100'
                        : level === 'very_high'
                        ? 'bg-red-50 text-red-700 border border-red-200'
                        : level === 'high'
                        ? 'bg-orange-50 text-orange-700 border border-orange-200'
                        : level === 'moderate'
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}
                  >
                    {level === 'very_high'
                      ? 'Very High'
                      : level === 'high'
                      ? 'High'
                      : level === 'moderate'
                      ? 'Moderate'
                      : 'Low'}
                  </span>
                </button>
              );
            })}

            {/* Weather Integration Panel in Left Sidebar */}
            <div className="pt-2 mt-2 border-t border-slate-200">
              <VillageWeatherWidget
                weather={weatherData}
                isLoading={isLoadingWeather}
                error={weatherError}
                onRefresh={refreshWeather}
                onApplyWeatherRainfall={handleApplyWeatherRainfall}
                appliedRainfall={simConfig.rainfallIntensity_mmh}
              />
            </div>
          </div>

          {/* Sidebar Footer with Quick Assessment Trigger */}
          <div className="p-2.5 border-t border-slate-200 bg-slate-50/60 shrink-0">
            <button
              onClick={() => setShowHazardModal(true)}
              className="w-full py-1.5 px-3 bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Activity className="w-3.5 h-3.5 text-blue-600" />
              <span>Full Hazard Profiles</span>
            </button>
          </div>
        </aside>

        {/* Mobile backdrop for sidebar */}
        {isMobileSidebarOpen && (
          <div
            onClick={() => setIsMobileSidebarOpen(false)}
            className="md:hidden fixed inset-0 top-14 bg-slate-900/40 backdrop-blur-2xs z-30"
          />
        )}

        {/* Right Main Content Area: Village Search, Map, Simulation Controls, and Results */}
        <main className="flex-1 flex flex-col min-w-0 h-full overflow-hidden relative">

          {/* Top Action Ribbon for Map, Simulation Controls & Layer Status (No duplicate hazard tabs) */}
          <div className="bg-white border-b border-slate-200 px-3 sm:px-4 py-1.5 flex items-center justify-between gap-2 text-xs shrink-0 z-20 overflow-x-auto scrollbar-none">
            {/* Left: Mobile Sidebar Trigger & Active Hazard Pill */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setIsMobileSidebarOpen(true)}
                className="md:hidden px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold flex items-center gap-1.5 border border-slate-200 cursor-pointer"
                title="Select Hazards"
              >
                <Layers className="w-3.5 h-3.5 text-blue-600" />
                <span>Hazards</span>
              </button>

              <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs font-medium border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-500">Active Layer:</span>
                <span className="font-semibold text-slate-900 capitalize">
                  {activeHazard}
                </span>
                <span
                  className={`text-[9px] font-bold uppercase px-1.5 py-0.2 rounded ml-0.5 ${
                    currentHazardDetail?.riskLevel === 'very_high'
                      ? 'bg-red-100 text-red-700'
                      : currentHazardDetail?.riskLevel === 'high'
                      ? 'bg-orange-100 text-orange-700'
                      : currentHazardDetail?.riskLevel === 'moderate'
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-emerald-100 text-emerald-700'
                  }`}
                >
                  {currentHazardDetail?.riskLevel?.replace('_', ' ') || 'Low'}
                </span>
              </div>
            </div>

            {/* Right: Map Type, Boundary, Plan, and Simulation Controls */}
            <div className="flex items-center gap-1.5 shrink-0 ml-auto">
              {/* Map / Satellite */}
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                <button
                  onClick={() => setMapType('roadmap')}
                  className={`px-2.5 py-1 rounded text-xs font-medium cursor-pointer transition-colors ${
                    mapType === 'roadmap' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Map
                </button>
                <button
                  onClick={() => setMapType('satellite')}
                  className={`px-2.5 py-1 rounded text-xs font-medium cursor-pointer transition-colors ${
                    mapType === 'satellite' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Satellite
                </button>
              </div>

              {/* Fit Location */}
              <button
                onClick={() => setCameraAction({ type: 'fit_village', timestamp: Date.now() })}
                className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 text-xs font-medium flex items-center gap-1 cursor-pointer"
              >
                <Compass className="w-3.5 h-3.5 text-blue-600" />
                <span className="hidden md:inline">Fit Boundary</span>
              </button>

              {/* Assess Risks Button */}
              <button
                onClick={() => setShowHazardModal(true)}
                className="px-3 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Activity className="w-3.5 h-3.5" />
                <span>Assess Risks</span>
              </button>

              {/* Plan Infrastructure Button */}
              <button
                onClick={() => setShowCandidatesModal(true)}
                className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-xs cursor-pointer"
              >
                <Wrench className="w-3.5 h-3.5 text-blue-400" />
                <span>Plan Infrastructure</span>
              </button>

              {/* Simulation Settings Trigger */}
              <button
                onClick={() => setShowSimSettingsModal(true)}
                className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
                title="Configure Storm & Compare Scenarios"
              >
                <Sliders className="w-3.5 h-3.5 text-blue-600" />
                <span className="hidden xl:inline">
                  {simConfig.scenario === 'baseline'
                    ? 'Baseline'
                    : simConfig.scenario === 'proposed_intervention'
                    ? 'Proposed Plan'
                    : 'Existing Drains'}{' '}
                  · {simConfig.rainfallIntensity_mmh} mm/h ({simConfig.rainfallDuration_hours}h)
                </span>
                <span className="xl:hidden">Config</span>
              </button>

              {/* Simulate Flood Button */}
              <button
                onClick={() => runFullSimulation(simConfig)}
                disabled={isSimulating}
                className="px-3 py-1 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
              >
                {isSimulating ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Simulating...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>Simulate Flood</span>
                  </>
                )}
              </button>
            </div>
          </div>

      {/* 3. Main Screen View Switcher */}
      {activeView === 'main' ? (
        <div className="flex-1 flex flex-col min-h-0 relative">
          
          {/* Main Google Map Component */}
          <div className="flex-1 relative w-full h-full min-h-[300px]">
            <VillageMap
              dataset={dataset}
              activeFloodGeoJson={latestResult.frames[latestResult.peakHour]?.floodPolygons}
              scenarioName={latestResult.scenario}
              selectedFeature={selectedFeature}
              onSelectFeature={setSelectedFeature}
              activeHazardPolygons={activeHazardPolygons}
              activeHazard={activeHazard}
              smartInterventions={interventions}
              onSelectIntervention={(item) => setSelectedFeature({ category: 'smart_intervention', properties: item })}
              earthquakes={earthquakes}
              selectedEarthquake={selectedEarthquake}
              onSelectEarthquake={(eq) => setSelectedEarthquake(eq)}
              mapType={mapType}
              onMapTypeChange={setMapType}
              cameraAction={cameraAction}
              onFitVillage={() => setCameraAction({ type: 'fit_village', timestamp: Date.now() })}
              onLocateBuildings={() => setCameraAction({ type: 'locate_buildings', timestamp: Date.now() })}
              simpleMode={false}
            />

            {/* Simulation Completion or Error Notification Banner */}
            {simFeedback && (
              <div
                className={`absolute top-3 left-1/2 -translate-x-1/2 z-30 px-3.5 py-2 rounded-xl shadow-xl text-xs flex items-center gap-2 backdrop-blur-md border animate-fade-in max-w-lg ${
                  simFeedback.type === 'error'
                    ? 'bg-red-950/95 text-white border-red-700'
                    : 'bg-slate-900/95 text-white border-slate-700'
                }`}
              >
                {simFeedback.type === 'error' ? (
                  <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                ) : (
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                )}
                <div className="min-w-0 pr-1">
                  <span className="font-semibold">{simFeedback.title}:</span>
                  <span className="text-slate-200 ml-1.5">{simFeedback.detail}</span>
                </div>
                <button
                  onClick={() => setSimFeedback(null)}
                  className="ml-auto text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Quota Exceeded Notification */}
            {quotaExceeded && (
              <div className="absolute top-3 right-3 z-30 bg-amber-50 border border-amber-200 text-amber-900 px-3 py-1.5 rounded-xl shadow-md text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Google Maps Platform standard evaluation quota in effect.</span>
              </div>
            )}
          </div>

          {/* 4. Bottom Summary Ribbon: Scannable Results & Data Readiness */}
          <div className="bg-white border-t border-slate-200 px-4 py-2.5 shrink-0 z-20">
            <div className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              
              {/* Card 1: Active Hazard Risk Status */}
              <div
                onClick={() => setShowHazardModal(true)}
                className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-100/70 transition-colors cursor-pointer"
              >
                <div className="flex items-center justify-between text-slate-500 text-[11px] mb-1">
                  <span className="font-semibold uppercase tracking-wider text-slate-600">
                    {currentHazardDetail?.title || 'Active Hazard'}
                  </span>
                  <span
                    className={`font-bold px-1.5 py-0.2 rounded text-[10px] uppercase ${
                      currentHazardDetail?.riskLevel === 'very_high'
                        ? 'bg-red-100 text-red-800'
                        : currentHazardDetail?.riskLevel === 'high'
                        ? 'bg-orange-100 text-orange-800'
                        : currentHazardDetail?.riskLevel === 'moderate'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {currentHazardDetail?.riskLevel?.replace('_', ' ') || 'Low'}
                  </span>
                </div>
                <div className="text-base font-bold text-slate-900 truncate">
                  {currentHazardDetail?.primaryMetricValue || 'Evaluated'}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5 truncate">
                  {currentHazardDetail?.exposedPopulation > 0
                    ? `~${currentHazardDetail.exposedPopulation.toLocaleString()} residents exposed`
                    : 'Low terrain exposure'}
                </div>
              </div>

              {/* Card 2: Smart Infrastructure Interventions */}
              <div
                onClick={() => setShowCandidatesModal(true)}
                className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-100/70 transition-colors cursor-pointer"
              >
                <div className="flex items-center justify-between text-slate-500 text-[11px] mb-1">
                  <span className="font-semibold uppercase tracking-wider text-slate-600">Smart Infrastructure</span>
                  <span className="text-blue-700 font-bold text-[10px]">
                    {candidateSites.length} Sites Ranked
                  </span>
                </div>
                <div className="text-base font-bold text-blue-700">
                  {candidateSites[0]?.title || 'Multi-Purpose Refuge'}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5 truncate">
                  Rank #1 Score: {candidateSites[0]?.suitabilityScore || 90}/100 · ₹{candidateSites[0]?.estimatedCostLakhs || 45}L
                </div>
              </div>

              {/* Card 3: Hydraulic Flood Simulation Results */}
              <div
                onClick={() => setShowSimSettingsModal(true)}
                className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-100/70 transition-colors cursor-pointer"
                title="Click to adjust storm parameters and compare scenarios"
              >
                <div className="flex items-center justify-between text-slate-500 text-[11px] mb-1">
                  <span className="font-semibold uppercase tracking-wider text-slate-600 truncate">
                    Flood Inundation ({latestResult.scenario === 'baseline' ? 'Baseline' : latestResult.scenario === 'proposed_intervention' ? 'Proposed Plan' : 'Existing Drains'})
                  </span>
                  <span className="text-purple-700 font-bold text-[10px] shrink-0 ml-1">
                    {latestResult.timestamp ? latestResult.timestamp : `Peak H+${latestResult.peakHour}`}
                  </span>
                </div>
                <div className="text-base font-bold text-slate-900">
                  {latestResult.maxInundatedArea_ha} Hectares
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5 truncate">
                  Max Depth: {latestResult.peakDepth_m}m · {latestResult.config.rainfallIntensity_mmh} mm/h rain · {latestResult.affectedRoads.filter((r) => r.impassable).length} impassable roads
                </div>
              </div>

              {/* Card 4: Verified Data Coverage Report */}
              <div
                onClick={() => setShowCoverageModal(true)}
                className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-100/70 transition-colors cursor-pointer"
              >
                <div className="flex items-center justify-between text-slate-500 text-[11px] mb-1">
                  <span className="font-semibold uppercase tracking-wider text-slate-600">Data Coverage</span>
                  <span className="text-emerald-700 font-semibold text-[10px] flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-600" />
                    <span>Audited</span>
                  </span>
                </div>
                <div className="text-base font-bold text-slate-900 truncate">
                  {coverageReport?.overallReadiness || 'Verified Geospatial Twin'}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5 truncate">
                  OSM Boundaries & Roads · Click to audit layers
                </div>
              </div>

            </div>
          </div>

        </div>
      ) : activeView === 'drainage' ? (
        <div className="flex-1 flex flex-col overflow-hidden bg-white">
          <div className="p-3 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <h2 className="font-bold text-sm text-slate-900">Drainage Network Planning & Hydraulic Routing</h2>
            <button
              onClick={() => setActiveView('main')}
              className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-semibold hover:bg-slate-50 cursor-pointer"
            >
              Back to Map
            </button>
          </div>
          <div className="flex-1 overflow-auto">
            <DrainagePlanningView
              dataset={dataset}
              latestResult={latestResult}
              proposedDrains={proposedDrains}
              onUpdateProposedDrains={setProposedDrains}
              proposedPonds={proposedPonds}
              onUpdateProposedPonds={setProposedPonds}
              selectedFeature={selectedFeature}
              onSelectFeature={setSelectedFeature}
              onRunComparison={() => {
                setActiveView('main');
                runFullSimulation({ ...simConfig, scenario: 'proposed_intervention' });
              }}
            />
          </div>
        </div>
      ) : activeView === 'impact' ? (
        <div className="flex-1 flex flex-col overflow-hidden bg-white">
          <div className="p-3 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <h2 className="font-bold text-sm text-slate-900">Multi-Hazard Socioeconomic Impact Assessment</h2>
            <button
              onClick={() => setActiveView('main')}
              className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-semibold hover:bg-slate-50 cursor-pointer"
            >
              Back to Map
            </button>
          </div>
          <div className="flex-1 overflow-auto">
            <ImpactAssessmentView
              latestResult={latestResult}
              dataset={dataset}
              onSelectBuilding={(bldId: string) => {
                const bld = dataset.buildings.features.find((b) => b.properties.id === bldId);
                if (bld) {
                  setSelectedFeature({ category: 'building', properties: bld.properties, geometry: bld.geometry });
                  setActiveView('main');
                }
              }}
            />
          </div>
        </div>
      ) : activeView === 'data' ? (
        <div className="flex-1 flex flex-col overflow-hidden bg-white">
          <div className="p-3 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <h2 className="font-bold text-sm text-slate-900">GeoJSON Data & GIS Layers Management</h2>
            <button
              onClick={() => setActiveView('main')}
              className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-semibold hover:bg-slate-50 cursor-pointer"
            >
              Back to Map
            </button>
          </div>
          <div className="flex-1 overflow-auto">
            <DataManagementView
              dataset={dataset}
              onUpdateDataset={setDataset}
              onResetToDemo={() => setDataset(DEMO_VILLAGE)}
            />
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col overflow-hidden bg-white">
          <div className="p-3 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <h2 className="font-bold text-sm text-slate-900">Scientific Model Details & Data Provenance</h2>
            <button
              onClick={() => setActiveView('main')}
              className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-semibold hover:bg-slate-50 cursor-pointer"
            >
              Back to Map
            </button>
          </div>
          <div className="flex-1 overflow-auto">
            <AboutModelView />
          </div>
        </div>
      )}

        </main>
      </div>

      {/* 5. Slide-Over Menu for Advanced Tools & Region Presets */}
      {showMenu && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white h-full shadow-2xl flex flex-col overflow-hidden text-xs">
            
            {/* Menu Header */}
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Bharat Digital Twin Tools</h3>
                <p className="text-[11px] text-slate-500">Nationwide hazard & civil planning platform</p>
              </div>
              <button
                onClick={() => setShowMenu(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-md cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Menu Body */}
            <div className="p-4 overflow-y-auto space-y-4 flex-1">
              
              {/* Region Benchmark Test Shortcuts */}
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">
                  Test Across Indian Geographic Regions:
                </span>
                <div className="space-y-1">
                  {NATIONWIDE_BENCHMARK_LOCATIONS.map((loc) => {
                    const isCurrent = loc.id === currentLocation.id;
                    return (
                      <button
                        key={loc.id}
                        onClick={() => {
                          setCurrentLocation(loc);
                          setShowMenu(false);
                        }}
                        className={`w-full text-left p-2 rounded-lg border transition-colors flex items-center justify-between cursor-pointer ${
                          isCurrent
                            ? 'bg-blue-50 border-blue-200 text-blue-900 font-semibold'
                            : 'bg-white border-slate-100 hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <div className="truncate pr-2">
                          <div className="truncate text-xs">{loc.name}</div>
                          <div className="text-[10px] text-slate-400 truncate">{loc.state} · {loc.regionCategory}</div>
                        </div>
                        <span className="text-[10px] text-slate-400 shrink-0 font-mono">
                          ~{loc.elevation_m}m
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Analysis & Planning Modals */}
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">
                  Multi-Hazard & Smart Planning:
                </span>
                <div className="space-y-1">
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      setShowHazardModal(true);
                    }}
                    className="w-full text-left p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 text-slate-800 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Activity className="w-4 h-4 text-blue-600" />
                      <span>Multi-Hazard Risk Registry (9 Hazards)</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>

                  <button
                    onClick={() => {
                      setShowMenu(false);
                      setShowEarthquakeModal(true);
                    }}
                    className="w-full text-left p-2.5 rounded-lg border border-rose-100 hover:bg-rose-50/50 text-slate-800 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Waves className="w-4 h-4 text-rose-600" />
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-rose-950">Real-Time Earthquakes (USGS Feed)</span>
                        {earthquakes.length > 0 && (
                          <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[10px] font-bold">
                            {earthquakes.length}
                          </span>
                        )}
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>

                  <button
                    onClick={() => {
                      setShowMenu(false);
                      setShowCandidatesModal(true);
                    }}
                    className="w-full text-left p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 text-slate-800 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Wrench className="w-4 h-4 text-purple-600" />
                      <span>AI Infrastructure Candidate Site Ranking</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>

                  <button
                    onClick={() => {
                      setShowMenu(false);
                      setShowInfraModal(true);
                    }}
                    className="w-full text-left p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 text-slate-800 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-emerald-600" />
                      <span>Smart Infrastructure Catalog & Cost-Benefit</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>

                  <button
                    onClick={() => {
                      setShowMenu(false);
                      setShowAiModal(true);
                    }}
                    className="w-full text-left p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 text-slate-800 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-blue-600" />
                      <span>AI Multi-Hazard Intelligence & Scenario Lab</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>

                  <button
                    onClick={() => {
                      setShowMenu(false);
                      setShowCoverageModal(true);
                    }}
                    className="w-full text-left p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 text-slate-800 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Database className="w-4 h-4 text-amber-600" />
                      <span>Data Coverage & Availability Audit</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>
                </div>
              </div>

              {/* Dedicated Engineering Views */}
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">
                  Detailed Engineering Views:
                </span>
                <div className="space-y-1">
                  <button
                    onClick={() => {
                      setActiveView('drainage');
                      setShowMenu(false);
                    }}
                    className="w-full text-left p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 text-slate-800 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Sliders className="w-4 h-4 text-blue-600" />
                      <span>Drainage Network Planning View</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>

                  <button
                    onClick={() => {
                      setActiveView('impact');
                      setShowMenu(false);
                    }}
                    className="w-full text-left p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 text-slate-800 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600" />
                      <span>Socioeconomic Impact Assessment</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>

                  <button
                    onClick={() => {
                      setActiveView('data');
                      setShowMenu(false);
                    }}
                    className="w-full text-left p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 text-slate-800 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <FileCode className="w-4 h-4 text-slate-600" />
                      <span>Import/Export GeoJSON Layers</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>

                  <button
                    onClick={() => {
                      setActiveView('about');
                      setShowMenu(false);
                    }}
                    className="w-full text-left p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 text-slate-800 flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-slate-600" />
                      <span>Model Documentation & Sources</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>
                </div>
              </div>

            </div>

            {/* Menu Footer */}
            <div className="p-3 border-t border-slate-200 bg-slate-50 text-[10px] text-slate-500 text-center">
              Bharat Village Twin v2.0 · OpenStreetMap & National Hazard Atlases
            </div>

          </div>
        </div>
      )}

      {/* 6. Modals */}
      {showHazardModal && (
        <MultiHazardDashboardModal
          summary={hazardSummary}
          activeHazard={activeHazard}
          onSelectHazard={(h) => setActiveHazard(h)}
          onClose={() => setShowHazardModal(false)}
          onOpenInfrastructure={() => setShowInfraModal(true)}
          onOpenAiAdvisory={() => setShowAiModal(true)}
        />
      )}

      {showInfraModal && (
        <SmartInfrastructurePlannerModal
          interventions={interventions}
          villagePopulation={dataset.totalPopulation}
          onToggleIntervention={toggleIntervention}
          onLocateIntervention={(item) => {
            setSelectedFeature({ category: 'smart_intervention', properties: item });
            setCameraAction({ type: 'recenter', timestamp: Date.now() });
          }}
          onClose={() => setShowInfraModal(false)}
          onOpenAiAdvisory={() => setShowAiModal(true)}
        />
      )}

      {showCandidatesModal && (
        <CandidateInfrastructureModal
          location={currentLocation}
          candidates={candidateSites}
          multiHazardSummary={hazardSummary}
          onLocateCandidate={handleLocateCandidate}
          onClose={() => setShowCandidatesModal(false)}
          onOpenAiAppraisal={() => setShowAiModal(true)}
        />
      )}

      {showAiModal && (
        <AiAdvisoryModal
          summary={hazardSummary}
          activeHazard={activeHazard}
          interventions={interventions}
          onClose={() => setShowAiModal(false)}
        />
      )}

      {showCoverageModal && coverageReport && (
        <DataCoverageReportModal
          coverage={coverageReport}
          onClose={() => setShowCoverageModal(false)}
          onImportGeoJson={(geoJson) => {
            setDataset((prev) => ({ ...prev, buildings: geoJson }));
            setShowCoverageModal(false);
          }}
        />
      )}

      {showSimSettingsModal && (
        <SimulationSettingsModal
          isOpen={showSimSettingsModal}
          onClose={() => setShowSimSettingsModal(false)}
          config={simConfig}
          onUpdateConfig={setSimConfig}
          onRunSimulation={runFullSimulation}
          isSimulating={isSimulating}
          dataset={dataset}
          latestResult={latestResult}
          liveWeatherRainfall={weatherData?.current.rainfall_mmh}
          weatherProvider={weatherData?.provider}
        />
      )}

      {showEarthquakeModal && (
        <EarthquakeMonitorModal
          currentLocation={currentLocation}
          onClose={() => setShowEarthquakeModal(false)}
          onSelectEarthquakeOnMap={(eq) => {
            setSelectedEarthquake(eq);
            setSelectedFeature({
              category: 'earthquake',
              properties: {
                ...eq,
                name: `M ${eq.mag.toFixed(1)} Earthquake — ${eq.place}`,
              },
              coordinates: [eq.longitude, eq.latitude],
            });
          }}
        />
      )}

    </div>
  );
}
