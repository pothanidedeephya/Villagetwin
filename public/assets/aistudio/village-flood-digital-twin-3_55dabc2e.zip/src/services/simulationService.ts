import type {
  BuildingProperties,
  RoadProperties,
  ScenarioType,
  SimulationConfig,
  SimulationFrame,
  SimulationResult,
  VillageDataset,
} from '../types/village';
import type { FeatureCollection, Polygon } from 'geojson';

/**
 * Standard contract for Village Flood Hydrological Simulation Engines.
 * Implementations can be local client-side illustrative models or
 * external EPA SWMM / 2D hydrodynamic solvers hosted on FastAPI / Cloud Run.
 */
export interface HydrologicalSimulationEngine {
  engineName: string;
  engineVersion: string;
  isIllustrativeDemo: boolean;
  runSimulation(dataset: VillageDataset, config: SimulationConfig): Promise<SimulationResult>;
}

/**
 * Simplified Illustrative Hydrological Engine for demonstration and UI testing.
 * Disclaimer: Uses modified rational runoff, elevation-hypsometric depression storage,
 * and conveyance factors. Not certified engineering hydraulic output.
 */
export class IllustrativeHydrologicalEngine implements HydrologicalSimulationEngine {
  engineName = 'Illustrative Rational-Depression Solver (Demo Prototype)';
  engineVersion = '0.9.2-illustrative';
  isIllustrativeDemo = true;

  async runSimulation(
    dataset: VillageDataset,
    config: SimulationConfig
  ): Promise<SimulationResult> {
    // Artificial small delay to reflect computation
    await new Promise((resolve) => setTimeout(resolve, 350));

    const totalHours = Math.max(config.rainfallDuration_hours + 4, 10);
    const frames: SimulationFrame[] = [];

    // Soil infiltration rate adjustment based on soil type
    let effectiveInfil = config.infiltrationRate_mmh;
    if (config.soilType === 'black_cotton') {
      // Swelling clay: high initial infiltration, dropping to very low steady state
      effectiveInfil = Math.min(effectiveInfil, 6.0);
    } else if (config.soilType === 'alluvial_clay') {
      effectiveInfil = Math.min(effectiveInfil, 8.5);
    } else {
      effectiveInfil = Math.min(effectiveInfil, 18.0);
    }

    // Drainage efficiency coefficient by scenario
    let drainageFactor = 0.0;
    let retentionStorageCapacity_m3 = 0;

    if (config.scenario === 'existing_drainage') {
      // Existing drains with maintenance/silt condition
      drainageFactor = 0.32 * config.desiltingFactor;
    } else if (config.scenario === 'proposed_intervention') {
      // High-capacity proposed box drain + retention basins
      drainageFactor = 0.78 * config.desiltingFactor;
      retentionStorageCapacity_m3 = 14360; // 7,560m3 basin + 6,800m3 deepened tank
    }

    if (config.tideOutfallCondition === 'high_surge_backwater') {
      drainageFactor *= 0.6; // Backwater choking at outfall
    }

    let cumulativeRain = 0;
    let maxOverallDepth = 0;
    let maxOverallArea = 0;
    let peakHour = 1;

    // Calibrate local datum to the selected village's actual elevation baseline
    const baseElevation = typeof dataset.elevation_m === 'number' ? dataset.elevation_m : 25.0;
    const lowGroundElevation = baseElevation - 0.4;

    const centerLng = dataset.center[0];
    const centerLat = dataset.center[1];

    // Village catchment area from administrative boundary polygon (default ~2.14 sq km)
    const villageAreaSqKm = dataset.boundary.features[0]?.properties.area_sqkm || 2.14;

    // Topographic slope factor: steep hill terrain (e.g. Sohra ~1430m) drains rapidly via gullies,
    // producing concentrated torrent depths but less widespread standing surface ponding area than flat coastal plains.
    const terrainSlopeFactor = baseElevation > 800 ? 0.40 : baseElevation > 150 ? 0.70 : 1.0;

    // Track frame states
    for (let h = 0; h <= totalHours; h++) {
      // Synthetic hyetograph: bell-curve rain peaking around duration/2
      let rainThisHour = 0;
      if (h > 0 && h <= config.rainfallDuration_hours) {
        const peak = config.rainfallDuration_hours / 2;
        const normalized = Math.exp(-Math.pow(h - peak, 2) / (2 * Math.pow(config.rainfallDuration_hours / 3.2, 2)));
        rainThisHour = config.rainfallIntensity_mmh * Math.max(0.2, normalized);
      }

      cumulativeRain += rainThisHour;

      // Excess rainfall = Rain - Infiltration
      const excessRain_mm = Math.max(0, rainThisHour - effectiveInfil);
      // Runoff volume over village catchment
      const rawRunoffVolume_m3 = (excessRain_mm / 1000) * villageAreaSqKm * 1_000_000 * config.runoffCoefficient;

      // Deduct drained volume
      const maxHourlyDrainDischarge_m3 = drainageFactor * 12500;
      const drainedThisHour_m3 = Math.min(rawRunoffVolume_m3 + (retentionStorageCapacity_m3 > 0 ? 1200 : 0), maxHourlyDrainDischarge_m3);

      // Remaining ponded storage index (normalized depth factor)
      const stormIntensityFactor = config.rainfallIntensity_mmh / 60; // 1.0 at 60 mm/hr
      const scenarioMultiplier =
        config.scenario === 'baseline' ? 1.0 : config.scenario === 'existing_drainage' ? 0.68 : 0.22;

      // Depth wave dynamic
      const activeHourEffect =
        h <= config.rainfallDuration_hours
          ? (h / config.rainfallDuration_hours) * 1.1
          : Math.max(0, 1.1 - (h - config.rainfallDuration_hours) * (config.scenario === 'proposed_intervention' ? 0.35 : 0.12));

      const frameMaxDepth = Math.max(
        0,
        Number((activeHourEffect * stormIntensityFactor * scenarioMultiplier * 1.15).toFixed(2))
      );

      if (frameMaxDepth > maxOverallDepth) {
        maxOverallDepth = frameMaxDepth;
        peakHour = h;
      }

      // Inundated Area (Hectares) calibrated to village area and topographic slope
      const frameInundatedHa = Math.max(
        0,
        Number((frameMaxDepth * 15.0 * terrainSlopeFactor * (villageAreaSqKm / 2.0) * (config.scenario === 'proposed_intervention' ? 0.38 : 0.85)).toFixed(1))
      );
      if (frameInundatedHa > maxOverallArea) {
        maxOverallArea = frameInundatedHa;
      }

      // Generate dynamic flood polygons based on local depression geometry
      const floodPolygons = generateIllustrativeFloodPolygons(centerLng, centerLat, frameMaxDepth, config.scenario);

      // Calculate impacted buildings in this frame
      const floodedBlds: string[] = [];
      const criticalFlooded: string[] = [];

      dataset.buildings.features.forEach((bld) => {
        const bldGround = bld.properties.groundElevation_m;
        const pondingWaterLevel = lowGroundElevation + frameMaxDepth;
        if (pondingWaterLevel > bldGround + (bld.properties.plinthHeight_cm / 100)) {
          floodedBlds.push(bld.properties.id);
          if (bld.properties.type !== 'residential') {
            criticalFlooded.push(bld.properties.name);
          }
        }
      });

      // Affected roads km
      const affectedKm = Number(
        dataset.roads.features
          .filter((rd) => lowGroundElevation + frameMaxDepth > rd.properties.elevation_m)
          .reduce((acc, rd) => acc + (rd.properties.length_m / 1000), 0)
          .toFixed(2)
      );

      frames.push({
        hour: h,
        rainfallThisHour_mm: Number(rainThisHour.toFixed(1)),
        cumulativeRain_mm: Number(cumulativeRain.toFixed(1)),
        runoffVolume_m3: Math.round(rawRunoffVolume_m3),
        drainedVolume_m3: Math.round(drainedThisHour_m3),
        inundatedArea_ha: frameInundatedHa,
        maxDepth_m: frameMaxDepth,
        floodedBuildingsCount: floodedBlds.length,
        criticalFacilitiesFlooded: criticalFlooded,
        affectedRoadsKm: affectedKm,
        floodPolygons,
      });
    }

    // Peak analysis calibrated to local terrain datum
    const peakWaterLevel = lowGroundElevation + maxOverallDepth;

    const affectedBuildings = dataset.buildings.features.map((bld) => {
      const plinthTop = bld.properties.groundElevation_m + bld.properties.plinthHeight_cm / 100;
      const depthAbovePlinth = Math.max(0, peakWaterLevel - plinthTop);
      let risk: 'safe' | 'low' | 'moderate' | 'severe' = 'safe';

      if (depthAbovePlinth > 0.45) risk = 'severe';
      else if (depthAbovePlinth > 0.15) risk = 'moderate';
      else if (depthAbovePlinth > 0) risk = 'low';

      return {
        id: bld.properties.id,
        name: bld.properties.name,
        type: bld.properties.type,
        depth_m: Number(depthAbovePlinth.toFixed(2)),
        risk,
      };
    });

    const affectedRoads = dataset.roads.features.map((rd) => {
      const depthOnRoad = Math.max(0, peakWaterLevel - rd.properties.elevation_m);
      return {
        id: rd.properties.id,
        name: rd.properties.name,
        depth_m: Number(depthOnRoad.toFixed(2)),
        impassable: depthOnRoad > 0.25, // Vehicles and emergency access stalled at 25cm
      };
    });

    const hasBuildings = dataset.buildings.features.length > 0;
    const floodedCount = affectedBuildings.filter((b) => b.depth_m > 0).length;
    const vulnerablePop = hasBuildings
      ? dataset.buildings.features
          .filter((b) => {
            const match = affectedBuildings.find((ab) => ab.id === b.properties.id);
            return match && match.depth_m > 0;
          })
          .reduce((acc, b) => acc + b.properties.occupants, 0)
      : 0;

    const farmlandHa = Number(
      (maxOverallArea * (config.scenario === 'baseline' ? 0.65 : config.scenario === 'existing_drainage' ? 0.45 : 0.15)).toFixed(1)
    );

    const estimatedLoss = Number(
      (
        floodedCount * 0.85 +
        farmlandHa * 0.45 +
        (affectedRoads.filter((r) => r.impassable).length * 1.2)
      ).toFixed(2)
    );

    const efficiency =
      config.scenario === 'baseline' ? 0 : config.scenario === 'existing_drainage' ? 32 : 86;

    return {
      scenario: config.scenario,
      config,
      frames,
      peakHour,
      totalRainfall_mm: Number(cumulativeRain.toFixed(1)),
      maxInundatedArea_ha: maxOverallArea,
      peakDepth_m: maxOverallDepth,
      affectedBuildings,
      affectedRoads,
      farmlandInundated_ha: farmlandHa,
      vulnerablePopulationAffected: vulnerablePop,
      estimatedLoss_lakhs: estimatedLoss,
      drainageEfficiency_percent: efficiency,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      modelLabel: 'Illustrative Rational-Depression Solver (Unvalidated Demo)',
      isIllustrative: true,
      modelScopeNote: hasBuildings
        ? 'Illustrative hydraulic model evaluated against mapped building plinths.'
        : 'Building footprints are unmapped in OpenStreetMap for this village. Dwelling inundation counts cannot be evaluated without mapped footprints.',
      buildingDataStatus: hasBuildings ? 'available_mapped' : 'unavailable_unmapped',
    };
  }
}

/**
 * Creates dynamic polygons reflecting natural topography in the village catchment:
 * Depressions along local low-points, agricultural backwaters, and drainage channels.
 * Scales dynamically with computed water depth and scenario.
 */
function generateIllustrativeFloodPolygons(
  centerLng: number,
  centerLat: number,
  depth_m: number,
  scenario: ScenarioType
): FeatureCollection<Polygon, { depth_m: number; category: string }> {
  if (depth_m <= 0.03) {
    return { type: 'FeatureCollection', features: [] };
  }

  // Scale bounds according to depth
  const spread = Math.min(0.009, depth_m * 0.0065);
  const features: FeatureCollection<Polygon, { depth_m: number; category: string }>['features'] = [];

  // Zone 1: Deepest depression (Local low elevation basin)
  if (depth_m > 0.05) {
    const d1 = depth_m;
    const cat1 = d1 > 0.5 ? 'severe' : d1 > 0.2 ? 'moderate' : 'low';
    features.push({
      type: 'Feature',
      properties: {
        depth_m: Number(d1.toFixed(2)),
        category: cat1,
      },
      geometry: {
        type: 'Polygon',
        coordinates: [
          [
            [centerLng - 0.0045 - spread * 0.4, centerLat - 0.001 - spread * 0.3],
            [centerLng - 0.0005 + spread * 0.3, centerLat - 0.0025 + spread * 0.2],
            [centerLng + 0.0035 + spread * 0.5, centerLat - 0.0055 + spread * 0.4],
            [centerLng + 0.0025 + spread * 0.4, centerLat - 0.0085 - spread * 0.2],
            [centerLng - 0.0025 - spread * 0.3, centerLat - 0.0075 - spread * 0.2],
            [centerLng - 0.0045 - spread * 0.4, centerLat - 0.001 - spread * 0.3],
          ],
        ],
      },
    });
  }

  // Zone 2: East Ayacut agricultural backwater (Only in baseline or heavy storm)
  if (depth_m > 0.35 && scenario !== 'proposed_intervention') {
    const d2 = depth_m * 0.7;
    features.push({
      type: 'Feature',
      properties: {
        depth_m: Number(d2.toFixed(2)),
        category: d2 > 0.5 ? 'severe' : 'moderate',
      },
      geometry: {
        type: 'Polygon',
        coordinates: [
          [
            [centerLng + 0.003, centerLat + 0.001],
            [centerLng + 0.0075 + spread * 0.3, centerLat + 0.0005],
            [centerLng + 0.009 + spread * 0.4, centerLat - 0.004],
            [centerLng + 0.0045, centerLat - 0.0045],
            [centerLng + 0.003, centerLat + 0.001],
          ],
        ],
      },
    });
  }

  // Zone 3: Shallow street pooling along Central Bazaar (if baseline/existing)
  if (depth_m > 0.25 && scenario === 'baseline') {
    features.push({
      type: 'Feature',
      properties: {
        depth_m: Number((depth_m * 0.45).toFixed(2)),
        category: 'low',
      },
      geometry: {
        type: 'Polygon',
        coordinates: [
          [
            [centerLng - 0.0015, centerLat + 0.0025],
            [centerLng + 0.002, centerLat + 0.002],
            [centerLng + 0.0025, centerLat + 0.0005],
            [centerLng - 0.001, centerLat + 0.001],
            [centerLng - 0.0015, centerLat + 0.0025],
          ],
        ],
      },
    });
  }

  return {
    type: 'FeatureCollection',
    features,
  };
}

/**
 * Singleton instance of the simulation engine.
 * Ready to be swapped with an EPA SWMM FastAPI backend endpoint when available.
 */
export const defaultSimulationEngine: HydrologicalSimulationEngine = new IllustrativeHydrologicalEngine();
