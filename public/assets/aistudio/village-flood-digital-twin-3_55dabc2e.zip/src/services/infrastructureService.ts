import type { InfrastructureIntervention, InfrastructurePlanSummary } from '../types/infrastructure';
import type { VillageDataset } from '../types/village';

/**
 * Generate smart multi-hazard infrastructure interventions catalog centered on the active village.
 */
/**
 * Generate smart multi-hazard infrastructure interventions catalog centered on the active village.
 * Generates region-, state-, and terrain-specific engineering interventions.
 */
export function getInitialInfrastructureInterventions(dataset: VillageDataset): InfrastructureIntervention[] {
  const [lng, lat] = dataset.center;
  const state = (dataset.state || '').toLowerCase();
  const elev = typeof dataset.elevation_m === 'number' ? dataset.elevation_m : 25;
  const pop = typeof dataset.totalPopulation === 'number' && dataset.totalPopulation > 0 ? dataset.totalPopulation : 3000;

  // 1. Mountain / Northeastern / Himalayan Terrain (e.g. Sohra in Meghalaya, Joshimath in Uttarakhand)
  if (elev > 500 || state.includes('meghalaya') || state.includes('uttarakhand') || state.includes('himachal') || state.includes('assam')) {
    const sdmaName = state.includes('meghalaya')
      ? 'Meghalaya State Disaster Management Authority (MSDMA)'
      : state.includes('uttarakhand')
      ? 'Uttarakhand SDMA / Disaster Mitigation & Management Centre'
      : `${dataset.state || 'State'} Disaster Management Authority`;

    return [
      {
        id: 'infra-torrent-chute',
        name: 'Steep-Gradient Torrent Cascade & Energy Dissipation Chute',
        category: 'drainage_flood',
        description: 'Stepped reinforced concrete storm cascade chute along natural hill gully to channel extreme rainfall runoff without slope scouring or road undercut.',
        technicalSpecs: 'Length: 850m, Drop: 45m, Manning n: 0.035, Step Baffles: 18 units, Flow Capacity: 5.4 m³/s',
        estimatedCostLakhs: 28.0,
        populationProtected: Math.round(pop * 0.45),
        riskReductionPercent: 64,
        lifespanYears: 30,
        annualMaintenanceLakhs: 0.7,
        location: [lng + 0.0015, lat + 0.0020],
        status: 'planned',
        isEnabled: true,
        hazardsMitigated: ['flood', 'waterlogging', 'landslide'],
        benefitCostRatio: 4.2,
        leadAgency: `${dataset.state} PWD (Roads) / SDRF`,
        timelineMonths: 6,
      },
      {
        id: 'infra-slope-retaining',
        name: 'Gabion-Anchored Hill Slope Retaining Wall & Rockfall Deflector',
        category: 'drainage_flood',
        description: 'Flexible tiered rock-filled wire mesh gabions with geotextile filter backing and deep soil nails along unstable roadside cutting slope.',
        technicalSpecs: 'Height: 4.5m stepped, Length: 320m, Soil Nails: 25mm dia x 9m depth @ 1.5m c/c, Subsurface Weep Drains: 75mm PVC',
        estimatedCostLakhs: 38.5,
        populationProtected: Math.round(pop * 0.55),
        riskReductionPercent: 72,
        lifespanYears: 35,
        annualMaintenanceLakhs: 0.9,
        location: [lng - 0.0025, lat + 0.0015],
        status: 'approved',
        isEnabled: true,
        hazardsMitigated: ['landslide', 'earthquake'],
        benefitCostRatio: 4.8,
        leadAgency: `${sdmaName} / Geological Survey of India (GSI)`,
        timelineMonths: 8,
      },
      {
        id: 'infra-seismic-retrofit-hill',
        name: 'BIS IS 1893 Zone V Life-Safety Structural Retrofitting for Lifelines',
        category: 'seismic_retrofit',
        description: 'Structural jacketing and seismic band reinforcement of community school, Anganwadi, and sub-health center under IS 4326/IS 13920 seismic standards.',
        technicalSpecs: 'Buildings: 2 Lifeline Blocks, Lintel Tie-Bands: 12mm TMT steel, Ferrocement Overlay: 30mm with weldmesh, Roof Anchors: 16mm bolts',
        estimatedCostLakhs: 14.5,
        populationProtected: Math.round(pop * 0.35),
        riskReductionPercent: 68,
        lifespanYears: 40,
        annualMaintenanceLakhs: 0.3,
        location: [lng + 0.0010, lat - 0.0015],
        status: 'planned',
        isEnabled: true,
        hazardsMitigated: ['earthquake'],
        benefitCostRatio: 4.1,
        leadAgency: 'Samagra Shiksha Abhiyan / SDRF Structural Safety Cell',
        timelineMonths: 4,
      },
      {
        id: 'infra-mountain-shelter',
        name: 'Insulated Climate-Resilient Mountain Evacuation Refuge',
        category: 'cyclone_shelter',
        description: 'Multi-purpose community shelter engineered for seismic resistance (Zone V) with insulated envelope, rooftop rainwater collection, and emergency solar microgrid.',
        technicalSpecs: 'Capacity: 500 persons, Thermal Insulation: Double-skin puff panels, Solar PV: 10kWp with 20kWh LFP storage, Cistern: 30,000L',
        estimatedCostLakhs: 46.0,
        populationProtected: Math.round(pop * 0.50),
        riskReductionPercent: 60,
        lifespanYears: 50,
        annualMaintenanceLakhs: 1.1,
        location: [lng - 0.0030, lat - 0.0025],
        status: 'planned',
        isEnabled: true,
        hazardsMitigated: ['earthquake', 'landslide', 'flood'],
        benefitCostRatio: 3.7,
        leadAgency: `${sdmaName} / World Bank Hill Resilience Project`,
        timelineMonths: 9,
      },
      {
        id: 'infra-spring-recharge',
        name: 'Springhead Rejuvenation & Infiltration Trench Corridor',
        category: 'drought_recharge',
        description: 'Catchment protection and contour infiltration trenches in the micro-watershed to maintain perennial discharge for gravity water supply during post-monsoon dry season.',
        technicalSpecs: 'Contour Trenches: 2,400m, Recharge Check Bunds: 6 units, Vegetative Riparian Buffer: 1.5 ha native evergreen trees',
        estimatedCostLakhs: 9.8,
        populationProtected: Math.round(pop * 0.60),
        riskReductionPercent: 50,
        lifespanYears: 20,
        annualMaintenanceLakhs: 0.4,
        location: [lng + 0.0040, lat + 0.0030],
        status: 'planned',
        isEnabled: true,
        hazardsMitigated: ['drought'],
        benefitCostRatio: 3.5,
        leadAgency: 'Soil & Water Conservation Dept / Jal Jeevan Mission',
        timelineMonths: 3,
      },
    ];
  }

  // 2. Coastal / Island / Delta Lowland (e.g. Kotturu in Andhra Pradesh, Odisha, Tamil Nadu)
  const sdmaName = state.includes('andhra')
    ? 'Andhra Pradesh State Disaster Management Authority (APSDMA)'
    : state.includes('odisha')
    ? 'Odisha State Disaster Management Authority (OSDMA)'
    : state.includes('tamil')
    ? 'Tamil Nadu Disaster Risk Reduction Agency (TNDRRA)'
    : `${dataset.state || 'State'} Disaster Management Authority`;

  return [
    {
      id: 'infra-drain-box',
      name: 'RCC Box Stormwater Drain with Silt Traps',
      category: 'drainage_flood',
      description: `Covered reinforced concrete U-box storm drain (1.2m x 1.0m) along ${dataset.villageName} settlement thoroughfare with debris catchment grates.`,
      technicalSpecs: 'Length: 1,420m, Flow Capacity: 2.85 m³/s, Longitudinal Gradient: 0.35%, Silt Cleanout Chambers: 14 units',
      estimatedCostLakhs: 26.5,
      populationProtected: Math.round(pop * 0.53),
      riskReductionPercent: 58,
      lifespanYears: 30,
      annualMaintenanceLakhs: 0.8,
      location: [lng + 0.001, lat + 0.002],
      status: 'planned',
      isEnabled: true,
      hazardsMitigated: ['waterlogging', 'flood'],
      benefitCostRatio: 3.8,
      leadAgency: 'Panchayat Raj Engineering Dept (PRED) / SDRF',
      timelineMonths: 5,
    },
    {
      id: 'infra-cyclone-shelter',
      name: 'Multi-Purpose Stilted Cyclone Shelter & Emergency Microgrid',
      category: 'cyclone_shelter',
      description: 'Elevated two-story RCC building on stilts (+3.0m ground clearance). Certified emergency cyclone/flood refuge with solar rooftop battery bank.',
      technicalSpecs: 'Plinth Area: 650 m², Capacity: 800 persons, Wind Resistance: 220 km/h, 15kWp Solar PV + 30kWh LiFePO4 battery, 40,000L Overhead Tank',
      estimatedCostLakhs: 52.0,
      populationProtected: Math.round(pop * 0.69),
      riskReductionPercent: 74,
      lifespanYears: 50,
      annualMaintenanceLakhs: 1.2,
      location: [lng - 0.002, lat + 0.003],
      status: 'approved',
      isEnabled: true,
      hazardsMitigated: ['cyclone', 'flood', 'tsunami', 'heatwave'],
      benefitCostRatio: 4.6,
      leadAgency: `${sdmaName} / World Bank NCRMP`,
      timelineMonths: 10,
    },
    {
      id: 'infra-evac-corridor',
      name: 'High-Level Climate-Resilient Evacuation Corridor',
      category: 'evacuation_road',
      description: `Elevation of ${dataset.villageName} Arterial Link road by 0.75m above 100-year flood levels with concrete pavement and cross-drainage culverts.`,
      technicalSpecs: 'Road Width: 5.5m (Intermediate Lane), Length: 1,650m, Pavement: M40 Cement Concrete, Culverts: 3 x 2.0m Box Slabs',
      estimatedCostLakhs: 34.0,
      populationProtected: Math.round(pop * 0.85),
      riskReductionPercent: 62,
      lifespanYears: 25,
      annualMaintenanceLakhs: 0.5,
      location: [lng - 0.005, lat - 0.001],
      status: 'planned',
      isEnabled: true,
      hazardsMitigated: ['flood', 'waterlogging', 'cyclone'],
      benefitCostRatio: 3.9,
      leadAgency: 'Roads & Buildings (R&B) Dept / PMGSY',
      timelineMonths: 6,
    },
    {
      id: 'infra-retention-tank',
      name: 'Village Sponge Wetland & Dual Recharge Shaft',
      category: 'drought_recharge',
      description: 'Desilting and embankment strengthening of the village irrigation tank to absorb peak monsoonal floods while recharging groundwater aquifers for summer resilience.',
      technicalSpecs: 'Storage Capacity: 65,000 m³, Desilting Volume: 22,000 m³, Recharge Shafts: 4 x 45m deep boreholes with inverted gravel filters',
      estimatedCostLakhs: 16.5,
      populationProtected: Math.round(pop * 0.60),
      riskReductionPercent: 48,
      lifespanYears: 20,
      annualMaintenanceLakhs: 0.6,
      location: [lng + 0.006, lat + 0.003],
      status: 'planned',
      isEnabled: true,
      hazardsMitigated: ['drought', 'flood', 'waterlogging'],
      benefitCostRatio: 3.4,
      leadAgency: 'Minor Irrigation Dept / Mission Amrit Sarovar',
      timelineMonths: 4,
    },
    {
      id: 'infra-cool-roofs',
      name: 'High-Albedo Cool Roof Program for Vulnerable Dwellings',
      category: 'heat_resilience',
      description: 'Application of high Solar Reflectance Index (SRI > 105) elastomeric thermal coating on tin and asbestos-roofed households, Anganwadis, and primary school.',
      technicalSpecs: 'Coated Area: 14,500 m², Surface Temperature Drop: 12°C–16°C, Indoor Ambient Drop: 4.5°C–6.0°C, Durability: 5 Years',
      estimatedCostLakhs: 4.8,
      populationProtected: Math.round(pop * 0.36),
      riskReductionPercent: 52,
      lifespanYears: 7,
      annualMaintenanceLakhs: 0.3,
      location: [lng - 0.001, lat - 0.004],
      status: 'planned',
      isEnabled: true,
      hazardsMitigated: ['heatwave'],
      benefitCostRatio: 5.1,
      leadAgency: 'Gram Panchayat Green Mission / NDMA Heat Action Plan',
      timelineMonths: 2,
    },
    {
      id: 'infra-tidal-sluice',
      name: 'Automated Tidal Flap Gate & Sluice Weir',
      category: 'drainage_flood',
      description: 'One-way flap gate at drainage outfall that permits outward gravity discharge during low tide and automatically seals during storm surges to prevent inland backflooding.',
      technicalSpecs: 'Aperture: 2 x 1.8m Stainless Steel Neoprene Flap Gates, Maximum Head Resistance: 3.5m surge, Automated Ultrasonic Level Sensors',
      estimatedCostLakhs: 11.2,
      populationProtected: Math.round(pop * 0.40),
      riskReductionPercent: 44,
      lifespanYears: 25,
      annualMaintenanceLakhs: 0.4,
      location: [lng + 0.009, lat - 0.010],
      status: 'planned',
      isEnabled: true,
      hazardsMitigated: ['flood', 'cyclone', 'tsunami'],
      benefitCostRatio: 4.2,
      leadAgency: 'Water Resources Dept / Coastal Zone Management',
      timelineMonths: 4,
    },
  ];
}

/**
 * Compute summary statistics for selected infrastructure interventions.
 */
export function calculateInfrastructureSummary(
  interventions: InfrastructureIntervention[],
  villagePopulation?: number
): InfrastructurePlanSummary {
  const totalBudget = interventions.reduce((acc, i) => acc + i.estimatedCostLakhs, 0);
  const active = interventions.filter((i) => i.isEnabled);
  const selectedBudget = active.reduce((acc, i) => acc + i.estimatedCostLakhs, 0);

  const popCap = typeof villagePopulation === 'number' && villagePopulation > 0 ? villagePopulation : 3500;

  // Protected population with deduplication factor
  const totalProtectedRaw = active.reduce((acc, i) => acc + i.populationProtected, 0);
  const netProtected = Math.min(popCap, Math.round(totalProtectedRaw * 0.72));

  // Risk reduction weighted by individual reduction
  const avgReduction = active.length > 0
    ? Math.round(active.reduce((acc, i) => acc + i.riskReductionPercent, 0) / active.length)
    : 0;

  const avgBCR = active.length > 0
    ? Number((active.reduce((acc, i) => acc + i.benefitCostRatio, 0) / active.length).toFixed(2))
    : 0;

  return {
    totalBudgetLakhs: Number(totalBudget.toFixed(1)),
    selectedBudgetLakhs: Number(selectedBudget.toFixed(1)),
    totalInterventionsCount: interventions.length,
    activeInterventionsCount: active.length,
    netProtectedPopulation: netProtected,
    compositeRiskReductionPercent: avgReduction,
    averageBCR: avgBCR,
  };
}
