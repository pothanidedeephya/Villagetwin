import type { WeatherData } from '../types/weather';

/**
 * Weather Service: Retrieves real-time meteorological conditions and forecasts
 * for the currently active village coordinates via the secure backend proxy endpoint.
 */
export async function fetchVillageWeather(
  lat: number,
  lng: number,
  villageName: string
): Promise<WeatherData> {
  try {
    const url = `/api/weather?lat=${lat}&lng=${lng}&name=${encodeURIComponent(villageName)}`;
    const res = await fetch(url);
    if (!res.ok) {
      const errJson = await res.json().catch(() => ({ error: `HTTP ${res.status}` }));
      throw new Error(errJson.error || `Weather API returned HTTP ${res.status}`);
    }
    const data: WeatherData = await res.json();
    return data;
  } catch (err: any) {
    // If backend proxy is unreachable, fallback to direct client-side open-meteo
    console.warn('Backend /api/weather call failed, falling back to direct open meteorological fetch:', err);
    return await fetchDirectOpenMeteo(lat, lng, villageName);
  }
}

/**
 * Direct client fallback if the Express proxy route is momentarily starting
 */
async function fetchDirectOpenMeteo(
  lat: number,
  lng: number,
  villageName: string
): Promise<WeatherData> {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m&hourly=temperature_2m,precipitation,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=auto&forecast_days=3`;
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Direct meteorological query returned HTTP ${res.status}`);
  }
  const data = await res.json();
  const cur = data.current || {};
  const hourly = data.hourly || {};
  const daily = data.daily || {};

  const getCond = (code: number) => {
    if (code === 0) return 'Clear Sky';
    if (code < 4) return 'Partly Cloudy';
    if (code < 60) return 'Overcast / Drizzle';
    if (code < 70) return 'Rain';
    if (code >= 95) return 'Thunderstorm';
    return 'Scattered Showers';
  };

  const hourlyForecast = (hourly.time || []).slice(0, 12).map((t: string, i: number) => ({
    time: t.split('T')[1]?.substring(0, 5) || t,
    temperature_c: Math.round(hourly.temperature_2m?.[i] ?? 28),
    condition: getCond(hourly.weather_code?.[i] ?? 0),
    rainfall_mm: Number((hourly.precipitation?.[i] || 0).toFixed(1)),
    windSpeed_kmh: 12,
  }));

  const dailyForecast = (daily.time || []).slice(0, 3).map((d: string, j: number) => ({
    date: d,
    dayName: j === 0 ? 'Today' : new Date(d).toLocaleDateString('en-US', { weekday: 'short' }),
    maxTemp_c: Math.round(daily.temperature_2m_max?.[j] ?? 32),
    minTemp_c: Math.round(daily.temperature_2m_min?.[j] ?? 24),
    condition: getCond(daily.weather_code?.[j] ?? 0),
    totalRainfall_mm: Number((daily.precipitation_sum?.[j] || 0).toFixed(1)),
  }));

  return {
    villageName,
    coordinates: [lng, lat],
    current: {
      temperature_c: Math.round(cur.temperature_2m ?? 28),
      condition: getCond(cur.weather_code ?? 0),
      humidity_percent: Math.round(cur.relative_humidity_2m ?? 65),
      windSpeed_kmh: Math.round(cur.wind_speed_10m ?? 12),
      rainfall_mmh: Number((cur.precipitation ?? 0).toFixed(1)),
    },
    hourlyForecast,
    dailyForecast,
    provider: 'Open Meteorological Service (Direct Client Connection)',
    isLiveApiKey: false,
    lastUpdated: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    sourceAttribution: 'WMO & National Meteorological Service Observational Models',
  };
}
