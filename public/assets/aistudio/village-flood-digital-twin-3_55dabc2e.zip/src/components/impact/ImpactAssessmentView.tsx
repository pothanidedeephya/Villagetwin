import React, { useState } from 'react';
import {
  ShieldAlert,
  Building,
  Route,
  Wheat,
  Users,
  Download,
  Printer,
  AlertTriangle,
  CheckCircle,
  FileText,
  Search,
  Filter,
  ArrowUpRight,
  LifeBuoy,
  Info,
  Calendar,
  Database,
  ShieldCheck,
} from 'lucide-react';
import type { SimulationResult, VillageDataset } from '../../types/village';

interface ImpactAssessmentViewProps {
  dataset: VillageDataset;
  latestResult: SimulationResult;
  onSelectBuilding: (buildingId: string) => void;
}

export const ImpactAssessmentView: React.FC<ImpactAssessmentViewProps> = ({
  dataset,
  latestResult,
  onSelectBuilding,
}) => {
  const [filterRisk, setFilterRisk] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Critical facilities
  const criticalTypes = ['school', 'clinic', 'panchayat', 'water_facility', 'agriculture'];
  const criticalBuildings = dataset.buildings.features.filter((b) =>
    criticalTypes.includes(b.properties.type)
  );

  // Merge building properties with simulation result
  const buildingsWithImpact = dataset.buildings.features.map((b) => {
    const impact = latestResult.affectedBuildings.find((ab) => ab.id === b.properties.id);
    const coords = b.geometry.coordinates[0][0];
    return {
      ...b.properties,
      coords,
      depth_m: impact ? impact.depth_m : 0,
      risk: impact ? impact.risk : ('safe' as const),
    };
  });

  const filteredBuildings = buildingsWithImpact.filter((b) => {
    if (filterRisk !== 'all' && b.risk !== filterRisk) return false;
    if (filterType !== 'all' && b.type !== filterType) return false;
    if (searchQuery.trim() && !b.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'Building ID',
      'Building Name',
      'Type',
      'Construction Type',
      'Longitude',
      'Latitude',
      'Ground Elevation (m AMSL)',
      'Plinth Height (cm)',
      'Water Depth Above Plinth (m)',
      'Risk Classification',
      'Estimated Occupants',
      'Data Provenance',
    ];

    const rows = buildingsWithImpact.map((b) => [
      b.id,
      `"${b.name}"`,
      b.type,
      b.constructionType,
      b.coords[0].toFixed(6),
      b.coords[1].toFixed(6),
      b.groundElevation_m,
      b.plinthHeight_cm,
      b.depth_m,
      b.risk,
      b.occupants,
      '"Gram Panchayat Survey / OpenStreetMap"',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${dataset.villageName}_Flood_Impact_Assessment.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintReport = () => {
    window.print();
  };

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-red-100 text-red-800 border border-red-200 text-[10px] font-bold px-2 py-0.5 rounded uppercase">
              Vulnerability Assessment
            </span>
            <span className="text-xs text-slate-500">
              Scenario: <strong className="text-slate-800 capitalize">{latestResult.scenario.replace('_', ' ')}</strong>
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Socio-Economic & Infrastructure Impact Assessment
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Geographic intersection of simulated water surface elevations with building plinths, road crests, and cropland for {dataset.villageName}.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500" />
            Export CSV
          </button>
          <button
            onClick={handlePrintReport}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Report
          </button>
        </div>
      </div>

      {/* Honest Data Provenance & Missing-Data Notice (Priority 6) */}
      <div className="bg-slate-50 border border-slate-300 rounded-2xl p-4 text-xs space-y-2">
        <div className="flex items-center gap-2 text-slate-800 font-bold">
          <Database className="w-4 h-4 text-blue-600" />
          <span>Data Provenance & Model Assumptions Audit</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-slate-600 pt-1 text-[11px]">
          <div>
            <strong className="text-slate-800">Terrain Elevation:</strong>
            <p>
              Topographic datum ~{typeof dataset.elevation_m === 'number' ? dataset.elevation_m : 25}m AMSL (Copernicus 30m DEM / Survey of India). Detailed micro-hydraulic routing requires sub-meter LiDAR survey.
            </p>
          </div>
          <div>
            <strong className="text-slate-800">Building Footprints:</strong>
            <p>
              {dataset.buildings.features.length > 0
                ? `${dataset.buildings.features.length} mapped facility plinths evaluated (+15cm to +45cm).`
                : 'Building vector footprints unavailable in OpenStreetMap for this village. Structural plinth ingress cannot be calculated.'}
            </p>
          </div>
          <div>
            <strong className="text-slate-800">Simulation Status:</strong>
            <p>
              Illustrative 2D rational runoff and depression storage model for {dataset.villageName}. Not an independently validated regulatory flood hazard map.
            </p>
          </div>
        </div>
      </div>

      {/* Impact Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Population at Risk</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {dataset.buildings.features.length > 0
              ? latestResult.vulnerablePopulationAffected
              : 'Data unavailable'}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            {dataset.buildings.features.length > 0
              ? 'Residents in flooded dwellings'
              : 'Building footprints unmapped in OSM'}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Exposed Buildings</span>
            <Building className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-2xl font-bold text-slate-800">
            {dataset.buildings.features.length > 0
              ? `${latestResult.affectedBuildings.filter((b) => b.depth_m > 0).length} / ${dataset.buildings.features.length}`
              : 'Not available'}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            {dataset.buildings.features.length > 0
              ? 'Flooded above floor plinth'
              : 'Building data not available — import verified village building footprints.'}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Farmland Inundated</span>
            <Wheat className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {latestResult.farmlandInundated_ha} ha
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Paddy & crop submergence
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Est. Financial Loss</span>
            <ShieldAlert className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-purple-700">
            ₹{latestResult.estimatedLoss_lakhs} L
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Structural & crop disruption
          </div>
        </div>
      </div>

      {/* Critical Facilities Lifeline Matrix */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <LifeBuoy className="w-4 h-4 text-blue-600" />
            Critical Community Infrastructure & Relief Shelters
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Safety margin calculation for designated cyclone relief shelters, clinics, and drinking water plants.
          </p>
        </div>

        {criticalBuildings.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {criticalBuildings.map((fac) => {
              const impact = latestResult.affectedBuildings.find((b) => b.id === fac.properties.id);
              const isFlooded = impact && impact.depth_m > 0;
              const baseElevation = typeof dataset.elevation_m === 'number' ? dataset.elevation_m : 25;
              const lowGroundElevation = baseElevation - 0.4;
              const waterElevation = lowGroundElevation + latestResult.peakDepth_m;
              const freeboardCm = Math.round(
                (fac.properties.plinthElevation_m - waterElevation) * 100
              );

              return (
                <div
                  key={fac.properties.id}
                  className={`p-4 rounded-xl border transition-all text-xs flex flex-col justify-between ${
                    isFlooded
                      ? 'border-red-300 bg-red-50/50'
                      : 'border-emerald-200 bg-emerald-50/30'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">
                          {fac.properties.type}
                        </span>
                        <h4 className="font-bold text-slate-900 text-sm mt-0.5">
                          {fac.properties.name}
                        </h4>
                      </div>
                      {isFlooded ? (
                        <span className="px-2 py-0.5 rounded-full font-bold text-[10px] bg-red-100 text-red-800 border border-red-300">
                          Flooded ({impact.depth_m}m)
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full font-bold text-[10px] bg-emerald-100 text-emerald-800 border border-emerald-300">
                          Protected (+{freeboardCm}cm)
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-2 mt-3 text-[11px] text-slate-600">
                      <div>
                        <span className="text-slate-400">Plinth Elevation:</span>
                        <div className="font-semibold text-slate-800">
                          {fac.properties.plinthElevation_m} m AMSL
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-400">Step Height:</span>
                        <div className="font-semibold text-slate-800">
                          +{fac.properties.plinthHeight_cm} cm
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                    <span className="text-slate-500">Capacity: {fac.properties.occupants} persons</span>
                    <span className={`font-semibold ${isFlooded ? 'text-red-700' : 'text-emerald-700'}`}>
                      {isFlooded ? 'Access Impaired' : 'Fully Operational'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-4 rounded-xl bg-slate-50 border border-dashed border-slate-300 text-center text-xs text-slate-500 space-y-1">
            <Building className="w-6 h-6 text-slate-400 mx-auto mb-1" />
            <p className="font-semibold text-slate-700">No Critical Facility Footprints Mapped</p>
            <p className="text-[11px] text-slate-500 max-w-md mx-auto">
              Public shelters, clinics, and school building vectors are not yet mapped in OpenStreetMap for {dataset.villageName}. Ground survey or Panchayat asset enumeration required.
            </p>
          </div>
        )}
      </div>

      {/* Road Inundation & Evacuation Corridors */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Route className="w-4 h-4 text-amber-600" />
            Road Network & Evacuation Corridors Inundation
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Vehicles and emergency ambulances are blocked when water depth exceeds 25 cm (0.25 m).
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 border-y border-slate-200 text-slate-600 font-semibold uppercase text-[10px]">
              <tr>
                <th className="py-2.5 px-3">Road Segment Name</th>
                <th className="py-2.5 px-3">Classification</th>
                <th className="py-2.5 px-3">Pavement</th>
                <th className="py-2.5 px-3">Crest Elevation</th>
                <th className="py-2.5 px-3">Simulated Depth</th>
                <th className="py-2.5 px-3">Accessibility Status</th>
                <th className="py-2.5 px-3">Lifeline Role</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {dataset.roads.features.map((rd) => {
                const impact = latestResult.affectedRoads.find((r) => r.id === rd.properties.id);
                const depth = impact ? impact.depth_m : 0;
                const isImpassable = depth > 0.25;

                return (
                  <tr key={rd.properties.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-3 font-semibold text-slate-900">
                      {rd.properties.name}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">{rd.properties.roadType}</td>
                    <td className="py-2.5 px-3 text-slate-600">{rd.properties.surface}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-700">
                      {rd.properties.elevation_m} m
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold">
                      {depth > 0 ? (
                        <span className={depth > 0.25 ? 'text-red-600' : 'text-amber-600'}>
                          {depth} m ({Math.round(depth * 100)} cm)
                        </span>
                      ) : (
                        <span className="text-emerald-600">Dry (0.0 m)</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3">
                      {isImpassable ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-800">
                          Impassable / Cut Off
                        </span>
                      ) : depth > 0 ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                          Caution (&lt;25cm)
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          Clear Access
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3">
                      {rd.properties.isEvacuationCorridor ? (
                        <span className="text-blue-700 font-semibold flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5 text-blue-600" />
                          Evacuation Lifeline
                        </span>
                      ) : (
                        <span className="text-slate-400">Internal Street</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* All Buildings Table with Filters */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Building className="w-4 h-4 text-indigo-600" />
              Complete Building Vulnerability Inventory
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Showing {filteredBuildings.length} of {buildingsWithImpact.length} mapped structures with geographic coordinates.
            </p>
          </div>

          {/* Filters Bar */}
          <div className="flex flex-wrap items-center gap-2 text-xs w-full sm:w-auto">
            <div className="relative flex-1 sm:w-48">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search building..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs outline-none focus:border-blue-500"
              />
            </div>

            <select
              value={filterRisk}
              onChange={(e) => setFilterRisk(e.target.value)}
              className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-none"
            >
              <option value="all">All Risk Levels</option>
              <option value="severe">Severe (&gt;45cm)</option>
              <option value="moderate">Moderate (15-45cm)</option>
              <option value="low">Low (&lt;15cm)</option>
              <option value="safe">Safe (Above Water)</option>
            </select>

            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 outline-none"
            >
              <option value="all">All Types</option>
              <option value="residential">Residential</option>
              <option value="school">School / Shelter</option>
              <option value="clinic">Clinic / PHC</option>
              <option value="panchayat">Panchayat</option>
              <option value="agriculture">Agriculture</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto max-h-96">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 sticky top-0 border-y border-slate-200 text-slate-600 font-semibold uppercase text-[10px] z-10">
              <tr>
                <th className="py-2.5 px-3">Building Name</th>
                <th className="py-2.5 px-3">Coordinates</th>
                <th className="py-2.5 px-3">Usage</th>
                <th className="py-2.5 px-3">Structure Type</th>
                <th className="py-2.5 px-3">Ground Elev.</th>
                <th className="py-2.5 px-3">Plinth Height</th>
                <th className="py-2.5 px-3">Simulated Inundation</th>
                <th className="py-2.5 px-3">Risk Level</th>
                <th className="py-2.5 px-3">Occupants</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredBuildings.map((bld) => (
                <tr key={bld.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-2 px-3 font-semibold text-slate-900">{bld.name}</td>
                  <td className="py-2 px-3 font-mono text-[10px] text-slate-500">
                    {bld.coords[1].toFixed(5)}, {bld.coords[0].toFixed(5)}
                  </td>
                  <td className="py-2 px-3 capitalize text-slate-600">{bld.type}</td>
                  <td className="py-2 px-3 text-slate-600">{bld.constructionType}</td>
                  <td className="py-2 px-3 font-mono text-slate-700">{bld.groundElevation_m} m</td>
                  <td className="py-2 px-3 font-mono text-slate-700">+{bld.plinthHeight_cm} cm</td>
                  <td className="py-2 px-3 font-mono font-bold">
                    {bld.depth_m > 0 ? (
                      <span className={bld.risk === 'severe' ? 'text-red-600' : 'text-amber-600'}>
                        {bld.depth_m} m ({Math.round(bld.depth_m * 100)} cm)
                      </span>
                    ) : (
                      <span className="text-emerald-600">Safe (0.0 m)</span>
                    )}
                  </td>
                  <td className="py-2 px-3">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        bld.risk === 'severe'
                          ? 'bg-red-100 text-red-800'
                          : bld.risk === 'moderate'
                          ? 'bg-amber-100 text-amber-800'
                          : bld.risk === 'low'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {bld.risk.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-slate-700 font-medium">{bld.occupants}</td>
                </tr>
              ))}
              {filteredBuildings.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500 text-xs font-medium">
                    {dataset.buildings.features.length === 0
                      ? 'Building data not available — import verified village building footprints.'
                      : 'No buildings match your current filters.'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
