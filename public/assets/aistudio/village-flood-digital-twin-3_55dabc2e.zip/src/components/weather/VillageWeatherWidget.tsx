import React, { useState } from 'react';
import {
  CloudSun,
  RefreshCw,
  Droplets,
  Wind,
  CloudRain,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Clock,
  ArrowRight,
  ShieldCheck,
  Check,
} from 'lucide-react';
import type { WeatherData } from '../../types/weather';

interface VillageWeatherWidgetProps {
  weather: WeatherData | null;
  isLoading: boolean;
  error: string | null;
  onRefresh: () => void;
  onApplyWeatherRainfall?: (rainfall_mmh: number) => void;
  appliedRainfall?: number;
}

export const VillageWeatherWidget: React.FC<VillageWeatherWidgetProps> = ({
  weather,
  isLoading,
  error,
  onRefresh,
  onApplyWeatherRainfall,
  appliedRainfall,
}) => {
  const [activeTab, setActiveTab] = useState<'current' | 'hourly' | 'daily'>('current');
  const [isExpanded, setIsExpanded] = useState(true);

  if (error && !weather) {
    return (
      <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 space-y-2">
        <div className="flex items-center justify-between text-slate-900 font-semibold">
          <span className="flex items-center gap-1.5 text-slate-800">
            <CloudSun className="w-3.5 h-3.5 text-slate-600" />
            <span>Local Weather Data</span>
          </span>
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="p-1 hover:bg-slate-200 rounded text-slate-600 cursor-pointer transition-colors"
            title="Retry weather retrieval"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
        <p className="text-[11px] text-slate-600 bg-white p-2 rounded border border-slate-200">
          {error}
        </p>
        <button
          onClick={onRefresh}
          className="w-full py-1 text-center bg-white border border-slate-300 rounded font-medium text-slate-700 hover:bg-slate-100 cursor-pointer"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  if (!weather && isLoading) {
    return (
      <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 flex items-center justify-center gap-2">
        <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-600" />
        <span>Retrieving weather observations...</span>
      </div>
    );
  }

  if (!weather) return null;

  const currentRain = weather.current.rainfall_mmh;
  const isRainApplied = appliedRainfall !== undefined && appliedRainfall === currentRain;

  return (
    <div className="bg-slate-50/80 border border-slate-200 rounded-lg overflow-hidden text-xs text-slate-700 transition-all">
      {/* Header Bar */}
      <div
        onClick={() => setIsExpanded(!isExpanded)}
        className="p-2.5 flex items-center justify-between bg-white border-b border-slate-200 cursor-pointer select-none"
      >
        <div className="flex items-center gap-2 min-w-0 pr-1">
          <CloudSun className="w-4 h-4 text-blue-700 shrink-0" />
          <div className="min-w-0">
            <div className="font-semibold text-slate-900 flex items-center gap-1.5 truncate">
              <span>{weather.villageName} Weather</span>
              <span className="font-mono text-xs font-bold text-slate-800">
                {weather.current.temperature_c}°C
              </span>
            </div>
            <div className="text-[10px] text-slate-500 truncate">
              {weather.current.condition} · Rain: {weather.current.rainfall_mmh} mm/h
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0 ml-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onRefresh();
            }}
            disabled={isLoading}
            className="p-1 hover:bg-slate-100 text-slate-500 hover:text-slate-800 rounded cursor-pointer transition-colors"
            title="Refresh weather data"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-blue-600' : ''}`} />
          </button>
          {isExpanded ? (
            <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
          ) : (
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          )}
        </div>
      </div>

      {/* Expanded Content */}
      {isExpanded && (
        <div className="p-3 space-y-2.5">
          {/* Tabs: Current | Hourly | 3-Day */}
          <div className="flex items-center bg-slate-200/70 p-0.5 rounded text-[11px] font-medium text-slate-600">
            <button
              onClick={() => setActiveTab('current')}
              className={`flex-1 py-1 rounded text-center transition-colors cursor-pointer ${
                activeTab === 'current'
                  ? 'bg-white text-slate-900 font-semibold shadow-xs'
                  : 'hover:text-slate-900'
              }`}
            >
              Current
            </button>
            <button
              onClick={() => setActiveTab('hourly')}
              className={`flex-1 py-1 rounded text-center transition-colors cursor-pointer ${
                activeTab === 'hourly'
                  ? 'bg-white text-slate-900 font-semibold shadow-xs'
                  : 'hover:text-slate-900'
              }`}
            >
              Hourly
            </button>
            <button
              onClick={() => setActiveTab('daily')}
              className={`flex-1 py-1 rounded text-center transition-colors cursor-pointer ${
                activeTab === 'daily'
                  ? 'bg-white text-slate-900 font-semibold shadow-xs'
                  : 'hover:text-slate-900'
              }`}
            >
              3-Day
            </button>
          </div>

          {/* Tab 1: Current Observations */}
          {activeTab === 'current' && (
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                <div className="bg-white p-2 rounded border border-slate-200 flex items-center justify-between">
                  <span className="text-slate-500 flex items-center gap-1">
                    <Droplets className="w-3 h-3 text-blue-600" />
                    <span>Humidity</span>
                  </span>
                  <span className="font-semibold text-slate-800">
                    {weather.current.humidity_percent}%
                  </span>
                </div>

                <div className="bg-white p-2 rounded border border-slate-200 flex items-center justify-between">
                  <span className="text-slate-500 flex items-center gap-1">
                    <Wind className="w-3 h-3 text-slate-600" />
                    <span>Wind</span>
                  </span>
                  <span className="font-semibold text-slate-800">
                    {weather.current.windSpeed_kmh} km/h
                  </span>
                </div>

                <div className="bg-white p-2 rounded border border-slate-200 flex items-center justify-between col-span-2">
                  <span className="text-slate-500 flex items-center gap-1">
                    <CloudRain className="w-3 h-3 text-blue-600" />
                    <span>Precipitation Rate</span>
                  </span>
                  <span className="font-semibold text-blue-700">
                    {weather.current.rainfall_mmh} mm/hr
                  </span>
                </div>
              </div>

              {/* Feed Rainfall to Simulation Trigger */}
              {onApplyWeatherRainfall && (
                <div className="pt-1">
                  <button
                    onClick={() => onApplyWeatherRainfall(weather.current.rainfall_mmh || 35)}
                    className="w-full py-1.5 px-2 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded text-[11px] font-medium text-blue-800 flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-1">
                      <CloudRain className="w-3 h-3 text-blue-600" />
                      <span>Use weather rain in simulation</span>
                    </span>
                    <span className="font-semibold font-mono">
                      {weather.current.rainfall_mmh} mm/h
                    </span>
                  </button>
                  <p className="text-[10px] text-slate-500 mt-1 italic leading-tight">
                    Distinction: Weather rain is observed/forecast meteorological data. Flood depths remain illustrative hydraulic calculations.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Hourly Forecast */}
          {activeTab === 'hourly' && (
            <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
              {weather.hourlyForecast.length > 0 ? (
                weather.hourlyForecast.map((h, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between py-1 px-1.5 bg-white rounded border border-slate-100 text-[11px]"
                  >
                    <span className="font-mono text-slate-500 w-12">{h.time}</span>
                    <span className="truncate flex-1 text-slate-700">{h.condition}</span>
                    <span className="font-mono font-semibold text-slate-800 w-10 text-right">
                      {h.temperature_c}°
                    </span>
                    <span className="font-mono text-blue-700 w-14 text-right">
                      {h.rainfall_mm}mm
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-[11px] text-slate-500 text-center py-2">
                  Hourly forecast details not provided on standard tier.
                </div>
              )}
            </div>
          )}

          {/* Tab 3: 3-Day Forecast */}
          {activeTab === 'daily' && (
            <div className="space-y-1">
              {weather.dailyForecast.length > 0 ? (
                weather.dailyForecast.map((d, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between py-1.5 px-2 bg-white rounded border border-slate-100 text-[11px]"
                  >
                    <span className="font-semibold text-slate-800 w-14">{d.dayName}</span>
                    <span className="truncate flex-1 text-slate-600">{d.condition}</span>
                    <div className="text-right font-mono">
                      <span className="text-slate-800 font-semibold">{d.maxTemp_c}°</span>
                      <span className="text-slate-400 text-[10px] ml-1">{d.minTemp_c}°</span>
                    </div>
                    <span className="font-mono text-blue-700 text-[10px] w-12 text-right">
                      {d.totalRainfall_mm}mm
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-[11px] text-slate-500 text-center py-2">
                  Multi-day forecast unavailable.
                </div>
              )}
            </div>
          )}

          {/* Footer Metadata & Provenance */}
          <div className="pt-1 border-t border-slate-200 text-[10px] text-slate-500 flex items-center justify-between">
            <span className="truncate" title={weather.provider}>
              Source: {weather.provider}
            </span>
            <span className="font-mono shrink-0 ml-1">Updated {weather.lastUpdated}</span>
          </div>

          {weather.notice && (
            <div className="text-[10px] text-slate-500 bg-white p-1.5 rounded border border-slate-200">
              {weather.notice}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
