import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Compass,
  ArrowRight,
  TrendingDown,
  Users,
  CheckCircle2,
  AlertTriangle,
  Layers,
  FileCheck,
  Building,
  Loader2,
} from 'lucide-react';
import type { InfrastructureCandidateSite, LocationSearchResult } from '../../types/nationwide';
import type { MultiHazardSummary } from '../../types/hazard';

interface CandidateInfrastructureModalProps {
  location: LocationSearchResult;
  candidates: InfrastructureCandidateSite[];
  multiHazardSummary: MultiHazardSummary;
  onLocateCandidate: (candidate: InfrastructureCandidateSite) => void;
  onClose: () => void;
  onOpenAiAppraisal: () => void;
}

export const CandidateInfrastructureModal: React.FC<CandidateInfrastructureModalProps> = ({
  location,
  candidates,
  multiHazardSummary,
  onLocateCandidate,
  onClose,
  onOpenAiAppraisal,
}) => {
  const [selectedId, setSelectedId] = useState<string>(candidates[0]?.id || '');
  const activeCandidate = candidates.find((c) => c.id === selectedId) || candidates[0];

  if (!activeCandidate) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden text-slate-800">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-blue-600" />
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                AI Infrastructure Candidate Site Planning & Ranking
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {location.displayName} · Grounded in Digital Elevation Models, road access buffers & multi-hazard exposure
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Candidate List & Detail Split */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden text-xs">
          
          {/* Left Column: Candidates Ranking List */}
          <div className="w-full md:w-80 border-r border-slate-200 overflow-y-auto p-3 space-y-2 bg-slate-50/50">
            <span className="text-[10px] uppercase font-bold text-slate-400 px-1 block mb-1">
              Top Ranked Candidate Sites ({candidates.length})
            </span>

            {candidates.map((c) => {
              const isSelected = activeCandidate.id === c.id;
              return (
                <button
                  key={c.id}
                  onClick={() => setSelectedId(c.id)}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                      : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.2 rounded uppercase ${
                        isSelected ? 'bg-blue-700 text-white' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      Rank #{c.rank}
                    </span>
                    <span
                      className={`text-[11px] font-bold ${
                        isSelected ? 'text-white' : 'text-blue-700'
                      }`}
                    >
                      {c.suitabilityScore}/100 Score
                    </span>
                  </div>

                  <div className="font-bold text-xs truncate">{c.title}</div>
                  <div className={`text-[10px] mt-0.5 truncate ${isSelected ? 'text-blue-100' : 'text-slate-500'}`}>
                    {c.infrastructureType} · ₹{c.estimatedCostLakhs} L
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Column: Detailed Candidate Appraisal */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            
            {/* Candidate Title & Metrics */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex items-center justify-between flex-wrap gap-2 mb-1.5">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-bold">
                  Rank #{activeCandidate.rank} Candidate
                </span>
                <span className="font-mono text-xs text-slate-500">
                  Coordinates: {activeCandidate.candidateCoordinates[1]}°N, {activeCandidate.candidateCoordinates[0]}°E
                </span>
              </div>

              <h3 className="text-base font-bold text-slate-900">{activeCandidate.title}</h3>
              <p className="text-xs text-slate-600 mt-0.5">{activeCandidate.justification}</p>

              <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-200/70 text-center">
                <div>
                  <span className="text-[10px] text-slate-500 block">Elevation Clearance</span>
                  <span className="font-bold text-slate-900 text-xs">
                    {activeCandidate.elevation_m}m AMSL
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Est. Capital Outlay</span>
                  <span className="font-bold text-blue-700 text-xs">
                    ₹{activeCandidate.estimatedCostLakhs} Lakhs
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Beneficiaries</span>
                  <span className="font-bold text-emerald-700 text-xs">
                    {activeCandidate.expectedBeneficiaries.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            {/* Evidence & Datasets Considered */}
            <div className="p-3.5 bg-white rounded-xl border border-slate-200">
              <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide mb-2 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-blue-600" />
                <span>Evidence & Geospatial Datasets Considered</span>
              </h4>
              <ul className="space-y-1 text-slate-600 text-[11px]">
                {activeCandidate.evidenceDatasets.map((ev, i) => (
                  <li key={i} className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                    <span>{ev}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Information Needed for Field Verification */}
            <div className="p-3.5 bg-amber-50/50 rounded-xl border border-amber-200 text-amber-950">
              <h4 className="font-bold text-amber-900 text-xs uppercase tracking-wide mb-2 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                <span>Information Still Needed for Field Verification</span>
              </h4>
              <ul className="space-y-1 text-amber-900/80 text-[11px]">
                {activeCandidate.fieldVerificationNeeded.map((fv, i) => (
                  <li key={i} className="flex items-center gap-1.5">
                    <span className="text-amber-600 font-bold">•</span>
                    <span>{fv}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Actions Bar */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => {
                  onLocateCandidate(activeCandidate);
                  onClose();
                }}
                className="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              >
                <Compass className="w-3.5 h-3.5 text-blue-600" />
                <span>Locate Candidate on Map</span>
              </button>

              <button
                onClick={() => {
                  onClose();
                  onOpenAiAppraisal();
                }}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>Generate Full AI Appraisal Brief</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 bg-slate-50/80 flex items-center justify-between text-[11px] text-slate-500">
          <span>
            Notice: All recommendations are preliminary planning support requiring geotechnical and regulatory sign-off.
          </span>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-md font-medium cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
