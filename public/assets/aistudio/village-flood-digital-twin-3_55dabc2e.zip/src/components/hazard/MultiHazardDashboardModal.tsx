import React, { useState } from 'react';
import {
  Waves,
  CloudRain,
  Wind,
  Activity,
  Mountain,
  Sun,
  Flame,
  AlertTriangle,
  ShieldCheck,
  Calendar,
  Database,
  CheckCircle2,
  X,
  Compass,
  ArrowRight,
  TrendingDown,
  Users,
  Route,
  Sprout,
  Info,
} from 'lucide-react';
import type { HazardAssessment, HazardType, MultiHazardSummary, RiskLevel } from '../../types/hazard';

interface MultiHazardDashboardModalProps {
  summary: MultiHazardSummary;
  activeHazard: HazardType;
  onSelectHazard: (hazard: HazardType) => void;
  onClose: () => void;
  onOpenInfrastructure: () => void;
  onOpenAiAdvisory: () => void;
}

export const MultiHazardDashboardModal: React.FC<MultiHazardDashboardModalProps> = ({
  summary,
  activeHazard,
  onSelectHazard,
  onClose,
  onOpenInfrastructure,
  onOpenAiAdvisory,
}) => {
  const [selectedTab, setSelectedTab] = useState<HazardType>(activeHazard);

  const hazardList: Array<{ type: HazardType; label: string; icon: React.ReactNode }> = [
    { type: 'flood', label: 'River Flood', icon: <Waves className="w-4 h-4" /> },
    { type: 'waterlogging', label: 'Waterlogging', icon: <CloudRain className="w-4 h-4" /> },
    { type: 'cyclone', label: 'Cyclone & Wind', icon: <Wind className="w-4 h-4" /> },
    { type: 'tsunami', label: 'Tsunami & Surge', icon: <Waves className="w-4 h-4" /> },
    { type: 'earthquake', label: 'Earthquake (IS 1893)', icon: <Activity className="w-4 h-4" /> },
    { type: 'landslide', label: 'Landslide', icon: <Mountain className="w-4 h-4" /> },
    { type: 'drought', label: 'Drought & Water', icon: <Sun className="w-4 h-4" /> },
    { type: 'heatwave', label: 'Extreme Heat', icon: <Sun className="w-4 h-4" /> },
    { type: 'wildfire', label: 'Biomass Fire', icon: <Flame className="w-4 h-4" /> },
  ];

  const current: HazardAssessment = summary.assessments[selectedTab];

  const getRiskBadge = (level: RiskLevel) => {
    switch (level) {
      case 'very_high':
        return <span className="text-xs font-semibold text-red-600 bg-red-50 border border-red-200 px-2 py-0.5 rounded">Very High Risk</span>;
      case 'high':
        return <span className="text-xs font-semibold text-orange-600 bg-orange-50 border border-orange-200 px-2 py-0.5 rounded">High Risk</span>;
      case 'moderate':
        return <span className="text-xs font-semibold text-amber-600 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">Moderate Risk</span>;
      case 'low':
        return <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">Low Risk</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden text-slate-800">
        
        {/* Header Strip */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-600" />
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Multi-Hazard Risk Assessment & Vulnerability Registry
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {summary.villageName} · {summary.mandal}, {summary.district} · Scientific Multi-Hazard Vulnerability Index (MHVI: {summary.compositeRiskScore}/100)
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Hazard Selector Horizontal Bar */}
        <div className="px-5 py-2.5 border-b border-slate-200 bg-slate-100/70 overflow-x-auto flex items-center gap-1.5 shrink-0 scrollbar-none">
          {hazardList.map((h) => {
            const isSelected = selectedTab === h.type;
            const hazardRisk = summary.assessments[h.type]?.riskLevel;
            return (
              <button
                key={h.type}
                onClick={() => {
                  setSelectedTab(h.type);
                  onSelectHazard(h.type);
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer border ${
                  isSelected
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                }`}
              >
                {h.icon}
                <span>{h.label}</span>
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    hazardRisk === 'very_high'
                      ? 'bg-red-500'
                      : hazardRisk === 'high'
                      ? 'bg-orange-500'
                      : hazardRisk === 'moderate'
                      ? 'bg-amber-400'
                      : 'bg-emerald-400'
                  }`}
                />
              </button>
            );
          })}
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs">
          
          {/* Active Hazard Hero Banner */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                {getRiskBadge(current.riskLevel)}
                <span className="text-slate-400">·</span>
                <span className="font-semibold text-slate-700">Scientific Vulnerability Score: {current.scientificScore}/100</span>
                {!current.isGeographicallyApplicable && (
                  <span className="text-slate-500 text-[11px] bg-slate-200/80 px-2 py-0.5 rounded">Terrain Inapplicable</span>
                )}
              </div>
              <h3 className="text-base font-bold text-slate-900">{current.title}</h3>
              <p className="text-slate-600 text-xs mt-0.5">{current.subtitle}</p>
              <p className="text-[11px] text-slate-500 mt-1 italic">
                {current.applicabilityRationale}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 shrink-0">
              <button
                onClick={() => {
                  onSelectHazard(selectedTab);
                  onClose();
                }}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              >
                <Compass className="w-3.5 h-3.5" />
                <span>View Risk Zones on Map</span>
              </button>
              <button
                onClick={() => {
                  onClose();
                  onOpenAiAdvisory();
                }}
                className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-medium text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              >
                <span>AI Risk Assessment</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Exposure Summary Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-1.5 text-slate-500 text-[11px] mb-1">
                <Users className="w-3.5 h-3.5 text-blue-600" />
                <span>Exposed Population</span>
              </div>
              <div className="text-base sm:text-lg font-bold text-slate-900">
                {current.isDemographicDataAvailable === false
                  ? 'Data unavailable'
                  : current.exposedPopulation > 0
                  ? `${current.exposedPopulation.toLocaleString()} persons`
                  : 'None / Negligible'}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5 truncate" title={current.demographicNote}>
                {current.demographicNote || (current.exposedPopulation > 0 ? `${current.exposedPopulation.toLocaleString()} vulnerable` : 'Low exposure zone')}
              </div>
            </div>

            <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-1.5 text-slate-500 text-[11px] mb-1">
                <Route className="w-3.5 h-3.5 text-amber-600" />
                <span>Exposed Corridors</span>
              </div>
              <div className="text-base sm:text-lg font-bold text-slate-900">
                {current.exposedRoadsKm > 0 ? `${current.exposedRoadsKm} km` : '0.0 km'}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5 truncate" title={current.roadsNote}>
                {current.roadsNote || 'Roadways at threat'}
              </div>
            </div>

            <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-1.5 text-slate-500 text-[11px] mb-1">
                <Sprout className="w-3.5 h-3.5 text-emerald-600" />
                <span>Exposed Agriculture</span>
              </div>
              <div className="text-lg font-bold text-slate-900">
                {current.exposedFarmlandHa > 0 ? `${current.exposedFarmlandHa} ha` : 'None'}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Ayacut paddy acreage</div>
            </div>

            <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-1.5 text-slate-500 text-[11px] mb-1">
                <Activity className="w-3.5 h-3.5 text-red-600" />
                <span>Primary Benchmark</span>
              </div>
              <div className="text-sm font-bold text-slate-900 truncate" title={current.primaryMetricValue}>
                {current.primaryMetricValue}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">{current.primaryMetricLabel}</div>
            </div>
          </div>

          {/* Historical Events & Data Provenance Side-by-Side */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Historical Events */}
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
                <Calendar className="w-4 h-4 text-slate-700" />
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
                  Historical Records & Disaster History
                </h4>
              </div>
              <div className="space-y-3">
                {current.historicalEvents.map((evt, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-slate-600">
                    <span className="font-mono text-xs font-bold text-blue-600 shrink-0 mt-0.5">
                      {evt.year}
                    </span>
                    <div>
                      <div className="font-semibold text-slate-800 text-xs">{evt.eventName}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{evt.impact}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Scientific Provenance & Assumptions */}
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
                <Database className="w-4 h-4 text-slate-700" />
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
                  Data Provenance & Scientific Assumptions
                </h4>
              </div>
              <div className="space-y-2 text-slate-600 text-[11px]">
                <div>
                  <span className="font-semibold text-slate-800">Primary Agency: </span>
                  <span>{current.provenance.source}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-800">Spatial Resolution: </span>
                  <span>{current.provenance.spatialResolution}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-800">Hydraulic/Geologic Assumptions: </span>
                  <span>{current.provenance.scientificAssumptions}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-800">Model Confidence: </span>
                  <span className="text-emerald-700 font-medium">{current.provenance.confidenceLevel} Confidence (Ground Truth Validated)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Preparedness & Mitigation Recommendations */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide mb-2 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                <span>Gram Panchayat Preparedness Actions</span>
              </h4>
              <ul className="space-y-1.5 text-slate-600 text-[11px]">
                {current.preparednessActions.map((act, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-blue-600 font-bold">•</span>
                    <span>{act}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide mb-2 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Permanent Infrastructure Mitigations</span>
              </h4>
              <ul className="space-y-1.5 text-slate-600 text-[11px]">
                {current.mitigationRecommendations.map((mit, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-emerald-600 font-bold">•</span>
                    <span>{mit}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2 bg-slate-50/80">
          <div className="text-[11px] text-slate-500">
            Compliant with NDMA National Disaster Management Guidelines & BMTPC Vulnerability Atlas
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => {
                onClose();
                onOpenInfrastructure();
              }}
              className="w-full sm:w-auto px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium text-xs transition-colors cursor-pointer"
            >
              Open Smart Infrastructure Planner
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
