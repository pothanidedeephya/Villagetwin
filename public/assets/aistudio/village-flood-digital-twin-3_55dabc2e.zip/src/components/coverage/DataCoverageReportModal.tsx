import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  AlertCircle,
  Database,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Info,
  Waves,
  CloudSun,
  Activity,
  Mountain,
  Droplets,
  Route,
  Building,
  History,
  ShieldAlert,
  Radio,
  ExternalLink,
} from 'lucide-react';
import type { LocationDataCoverageReport, LayerCoverageDetail } from '../../types/nationwide';

interface DataCoverageReportModalProps {
  coverage: LocationDataCoverageReport;
  onClose: () => void;
  onImportGeoJson?: (geoJson: any) => void;
}

export const DataCoverageReportModal: React.FC<DataCoverageReportModalProps> = ({
  coverage,
  onClose,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'real_observed' | 'calculated_output' | 'missing'>('all');

  const layerEntries = Object.entries(coverage.layers || {}) as [string, LayerCoverageDetail][];

  const filteredLayers = layerEntries.filter(([_, layer]) => {
    if (filterType === 'all') return true;
    if (filterType === 'missing') return layer.status === 'unavailable' || layer.dataClassification === 'missing';
    return layer.dataClassification === filterType;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'complete':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3" /> Available (Real)
          </span>
        );
      case 'partial':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
            <AlertCircle className="w-3 h-3" /> Partial Coverage
          </span>
        );
      case 'unavailable':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
            <AlertCircle className="w-3 h-3" /> Missing / Unmapped
          </span>
        );
    }
  };

  const getClassificationBadge = (classification?: string) => {
    switch (classification) {
      case 'real_observed':
        return (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            Real Observed Data
          </span>
        );
      case 'calculated_output':
        return (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-purple-50 text-purple-700 border border-purple-200">
            Model Calculation Output
          </span>
        );
      case 'illustrative_baseline':
        return (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            Illustrative Baseline
          </span>
        );
      case 'missing':
        return (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            Missing / Unverified
          </span>
        );
      default:
        return null;
    }
  };

  const getLayerIcon = (key: string) => {
    switch (key) {
      case 'weather': return <CloudSun className="w-4 h-4 text-sky-600" />;
      case 'earthquakes': return <Waves className="w-4 h-4 text-rose-600" />;
      case 'elevation': return <Mountain className="w-4 h-4 text-emerald-600" />;
      case 'waterways': return <Droplets className="w-4 h-4 text-blue-600" />;
      case 'roads': return <Route className="w-4 h-4 text-amber-600" />;
      case 'buildings': return <Building className="w-4 h-4 text-indigo-600" />;
      case 'disasters': return <History className="w-4 h-4 text-purple-600" />;
      case 'alerts': return <Radio className="w-4 h-4 text-red-600" />;
      default: return <Database className="w-4 h-4 text-slate-600" />;
    }
  };

  const warnings = coverage.coverageWarnings || [
    'Building Footprint Gap: Building footprints are not yet mapped in OpenStreetMap for this village. Settlement-level calculations are used without fabricating synthetic buildings.',
    'Elevation Resolution: 30m satellite DEM provides macro-slope routing. Micro-drainage and individual plinth assessments require sub-meter drone / RTK-GNSS survey.',
    'Scientific Model Scope: 2D pluvial hydrodynamic simulations calculate water routing scenarios from physical hydrologic equations, not statutory regulatory flood zone demarcations.',
    'Seismic Instrumental Observation: Earthquake records are instrumental observations from USGS. Earthquakes cannot be predicted.',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-xs animate-fade-in overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full overflow-hidden border border-slate-200 my-auto flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50/80 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-700 border border-blue-500/20">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900 text-base">Village Data Coverage & Reliability Audit</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                  {coverage.overallReadiness}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Target Habitation: <span className="font-semibold text-slate-800">{coverage.displayName}</span>
                {coverage.center && ` [${coverage.center[1].toFixed(3)}°N, ${coverage.center[0].toFixed(3)}°E]`}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Audit Content */}
        <div className="p-5 max-h-[75vh] overflow-y-auto space-y-5">
          {/* Prominent Data-Coverage Warnings & Model Limitations Banner */}
          <div className="p-4 bg-amber-50/90 border border-amber-200/90 rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-950 uppercase tracking-wide">
              <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
              <span>Critical Data Limitations & Coverage Warnings</span>
            </div>
            <ul className="space-y-1.5 pl-6 list-disc text-xs text-amber-900 leading-relaxed">
              {warnings.map((warn, i) => (
                <li key={i}>{warn}</li>
              ))}
            </ul>
          </div>

          {/* Overall Audit Meta Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] font-semibold text-slate-500 uppercase">Readiness Tier</span>
              <div className="text-sm font-bold text-slate-900 mt-0.5">{coverage.overallReadiness}</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] font-semibold text-slate-500 uppercase">Audited Layers</span>
              <div className="text-sm font-bold text-blue-700 mt-0.5">{layerEntries.length} Datasets Verified</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] font-semibold text-slate-500 uppercase">Audit Timestamp</span>
              <div className="text-xs font-medium text-slate-700 mt-0.5 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>{new Date(coverage.lastAuditTimestamp).toLocaleDateString()}</span>
              </div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] font-semibold text-slate-500 uppercase">Fabrication Policy</span>
              <div className="text-xs font-bold text-emerald-700 mt-0.5 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Zero Mock Data</span>
              </div>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
              Comprehensive Dataset Coverage Matrix
            </h4>
            <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg text-xs">
              <button
                onClick={() => setFilterType('all')}
                className={`px-2.5 py-1 rounded-md font-medium cursor-pointer transition-colors ${
                  filterType === 'all' ? 'bg-white text-slate-900 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All ({layerEntries.length})
              </button>
              <button
                onClick={() => setFilterType('real_observed')}
                className={`px-2.5 py-1 rounded-md font-medium cursor-pointer transition-colors ${
                  filterType === 'real_observed' ? 'bg-white text-blue-700 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Real Observations
              </button>
              <button
                onClick={() => setFilterType('calculated_output')}
                className={`px-2.5 py-1 rounded-md font-medium cursor-pointer transition-colors ${
                  filterType === 'calculated_output' ? 'bg-white text-purple-700 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Calculations
              </button>
              <button
                onClick={() => setFilterType('missing')}
                className={`px-2.5 py-1 rounded-md font-medium cursor-pointer transition-colors ${
                  filterType === 'missing' ? 'bg-white text-rose-700 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Missing Data
              </button>
            </div>
          </div>

          {/* Layer Audit Cards */}
          <div className="space-y-3">
            {filteredLayers.map(([key, layer]) => (
              <div
                key={key}
                className="p-4 bg-white border border-slate-200 rounded-xl hover:border-slate-300 transition-all shadow-2xs space-y-2.5"
              >
                {/* Header row */}
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-slate-100 border border-slate-200">
                      {getLayerIcon(key)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-900">{layer.layerName || key}</span>
                        {getClassificationBadge(layer.dataClassification)}
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5">{layer.notes}</p>
                    </div>
                  </div>
                  <div>{getStatusBadge(layer.status)}</div>
                </div>

                {/* Audit Grid */}
                <div className="pt-2 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 text-[11px] text-slate-600 bg-slate-50/60 p-2.5 rounded-lg">
                  <div>
                    <span className="text-slate-400 font-semibold block">Official Source:</span>
                    <span className="font-medium text-slate-800">{layer.source}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 font-semibold block">Geographic Scope:</span>
                    <span className="font-medium text-slate-800">{layer.geographicCoverage || 'Habitation Bounding Box'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 font-semibold block">Update Frequency:</span>
                    <span className="font-medium text-slate-800">{layer.updateFrequency || 'Periodic Ingestion'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 font-semibold block">Feature Count:</span>
                    <span className="font-semibold text-slate-900">{layer.featureCount} records</span>
                  </div>
                </div>

                {/* Calculation Usage */}
                {layer.usedInCalculations && (
                  <div className="text-[11px] bg-blue-50/70 border border-blue-100/80 px-3 py-1.5 rounded-lg text-blue-900 flex items-start gap-1.5">
                    <Info className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold">Application Usage in Calculations:</span>{' '}
                      <span>{layer.usedInCalculations}</span>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Integrity Guarantee */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p className="text-xs text-slate-600 leading-relaxed">
              <strong className="text-slate-800">Geospatial Integrity Guarantee:</strong> Missing building footprints or local drains are explicitly recorded as unmapped rather than fabricated with artificial coordinates. All hazard calculations denote whether they rely on direct observations (weather, USGS seismicity) or physical hydrodynamic simulations.
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-500">
            Audit standard complies with National Data Sharing & Accessibility Policy (NDSAP) guidelines.
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            Close Audit
          </button>
        </div>
      </div>
    </div>
  );
};
