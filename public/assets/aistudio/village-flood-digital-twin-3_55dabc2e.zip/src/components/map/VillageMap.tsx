import React, { useEffect, useRef, useState, useMemo } from 'react';
import {
  APIProvider,
  Map,
  useMap,
} from '@vis.gl/react-google-maps';
import type { FeatureCollection, Polygon, LineString } from 'geojson';
import type {
  VillageDataset,
  DrainageProperties,
  RetentionPondProperties,
} from '../../types/village';
import type { HazardType, RiskLevel } from '../../types/hazard';
import type { InfrastructureIntervention } from '../../types/infrastructure';
import {
  Search,
  X,
  Building,
  Building2,
  Waves,
  Compass,
  AlertTriangle,
  Droplets,
  MapPin,
  Home,
  Route,
  ChevronDown,
  ChevronUp,
  Key,
  Loader2,
  Maximize2,
  Minimize2,
  Info,
  Shield,
  Wrench,
  Sparkles,
  Activity,
  ExternalLink,
} from 'lucide-react';
import type { EarthquakeEvent } from '../../types/earthquake';

export interface VillageMapCameraAction {
  type: 'fit_village' | 'locate_buildings' | 'recenter';
  timestamp: number;
}

export interface VillageMapProps {
  dataset: VillageDataset;
  activeFloodGeoJson?: FeatureCollection<Polygon, { depth_m: number; category: string }>;
  scenarioName?: string;
  selectedFeature?: any | null;
  onSelectFeature?: (feature: any | null) => void;
  // Multi-Hazard and Infrastructure
  activeHazardPolygons?: FeatureCollection<Polygon, any>;
  activeHazard?: HazardType;
  smartInterventions?: InfrastructureIntervention[];
  onSelectIntervention?: (intervention: InfrastructureIntervention) => void;
  // Real-Time USGS Earthquakes
  earthquakes?: EarthquakeEvent[];
  selectedEarthquake?: EarthquakeEvent | null;
  onSelectEarthquake?: (eq: EarthquakeEvent) => void;
  // Drawing mode for Drainage Planner
  isDrawingMode?: boolean;
  drawingType?: 'drain' | 'retention';
  onAddDrawnFeature?: (coordinates: [number, number][], type: 'drain' | 'retention') => void;
  proposedDrainsOverride?: FeatureCollection<LineString, DrainageProperties>;
  proposedPondsOverride?: FeatureCollection<Polygon, RetentionPondProperties>;
  // Beginner-friendly mode
  simpleMode?: boolean;
  mapType?: 'roadmap' | 'satellite';
  onMapTypeChange?: (mapType: 'roadmap' | 'satellite') => void;
  cameraAction?: VillageMapCameraAction;
  onFitVillage?: () => void;
  onLocateBuildings?: () => void;
}

export const VillageMap: React.FC<VillageMapProps> = ({
  dataset,
  activeFloodGeoJson,
  scenarioName,
  selectedFeature,
  onSelectFeature,
  activeHazardPolygons,
  activeHazard,
  smartInterventions = [],
  onSelectIntervention,
  earthquakes = [],
  selectedEarthquake = null,
  onSelectEarthquake,
  isDrawingMode = false,
  drawingType = 'drain',
  onAddDrawnFeature,
  proposedDrainsOverride,
  proposedPondsOverride,
  simpleMode = false,
  mapType: externalMapType,
  onMapTypeChange,
  cameraAction,
  onFitVillage,
  onLocateBuildings,
}) => {
  // Read API Key from environment variable - never hardcoded
  const rawKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';
  const [userKeyInput, setUserKeyInput] = useState('');
  const [activeApiKey, setActiveApiKey] = useState(rawKey);

  // Basemap switch: 'roadmap' vs 'satellite' (hybrid with labels)
  const [internalMapType, setInternalMapType] = useState<'roadmap' | 'satellite'>('roadmap');
  const mapType = externalMapType !== undefined ? externalMapType : internalMapType;
  const setMapType = (nextType: 'roadmap' | 'satellite') => {
    setInternalMapType(nextType);
    if (onMapTypeChange) onMapTypeChange(nextType);
  };

  // Internal camera action if not provided via props
  const [internalCameraAction, setInternalCameraAction] = useState<VillageMapCameraAction | undefined>(cameraAction);
  const effectiveCameraAction = cameraAction || internalCameraAction;

  // Search state (for standard mode)
  const [searchQuery, setSearchQuery] = useState('');

  // UI Panels state
  const [legendExpanded, setLegendExpanded] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Error & loading states
  const [mapError, setMapError] = useState<string | null>(null);

  // Listen for Google Maps auth or quota failures
  useEffect(() => {
    const handleAuthFailure = () => {
      setMapError(
        'Google Maps authentication failed. Ensure Maps JavaScript API is enabled in your Google Cloud project with an active billing account.'
      );
    };
    const handleQuotaFailure = () => {
      setMapError(
        'Google Maps Platform quota reached. Review your Google Cloud billing or quota allocations.'
      );
    };

    window.addEventListener('gmp-quota-exceeded', handleQuotaFailure);
    (window as any).gm_authFailure = handleAuthFailure;

    return () => {
      window.removeEventListener('gmp-quota-exceeded', handleQuotaFailure);
    };
  }, []);

  // Independent Layer visibility controls (Flood, Buildings, Roads, Drainage, Earthquakes)
  const [visibleLayers, setVisibleLayers] = useState({
    floodExtent: true,
    buildings: true,
    roads: true,
    drainageExisting: true,
    drainageProposed: true,
    retentionPonds: true,
    waterBodies: true,
    boundary: true,
    earthquakes: true,
  });

  const toggleLayer = (layerKey: keyof typeof visibleLayers) => {
    setVisibleLayers((prev) => ({ ...prev, [layerKey]: !prev[layerKey] }));
  };

  // Search items list
  const searchableFeatures = useMemo(() => {
    const list: Array<{ id: string; name: string; type: string; coords: { lat: number; lng: number } }> = [];
    dataset.buildings.features.forEach((b) => {
      const coord = b.geometry.coordinates[0][0];
      list.push({
        id: b.properties.id,
        name: b.properties.name,
        type: b.properties.type,
        coords: { lat: coord[1], lng: coord[0] },
      });
    });
    dataset.roads.features.forEach((r) => {
      const coord = r.geometry.coordinates[0];
      list.push({
        id: r.properties.id,
        name: r.properties.name,
        type: r.properties.roadType,
        coords: { lat: coord[1], lng: coord[0] },
      });
    });
    return list;
  }, [dataset]);

  const searchResults = useMemo(() => {
    if (!searchQuery.trim() || searchQuery.length < 2) return [];
    return searchableFeatures
      .filter((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()))
      .slice(0, 5);
  }, [searchQuery, searchableFeatures]);

  // If no API key is provided, display helpful setup screen
  if (!activeApiKey) {
    return (
      <div className="w-full h-full min-h-[480px] flex flex-col items-center justify-center bg-slate-50 text-slate-800 p-6">
        <div className="max-w-md w-full bg-white border border-slate-200 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 mx-auto">
            <Key className="w-6 h-6" />
          </div>

          <div className="text-center space-y-1">
            <h3 className="text-base font-bold text-slate-900">
              Google Maps API Key Required
            </h3>
            <p className="text-xs text-slate-500">
              To display real interactive roadmaps and satellite imagery, provide a Google Maps Platform API key.
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs text-slate-600 space-y-2">
            <div className="font-bold text-blue-700 flex items-center gap-1.5">
              <Info className="w-4 h-4" /> Google Cloud Setup Requirements
            </div>
            <ol className="list-decimal pl-4 space-y-1 text-[11px] text-slate-500">
              <li>Open your project in Google Cloud Console.</li>
              <li>Link an active Cloud Billing account.</li>
              <li>Enable the <strong>Maps JavaScript API</strong>.</li>
              <li>Set <code className="text-blue-700 font-mono">VITE_GOOGLE_MAPS_API_KEY</code> or paste below.</li>
            </ol>
          </div>

          <div className="space-y-2 pt-1">
            <label className="block text-xs font-semibold text-slate-700">
              Enter API Key for this Session:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="AIzaSy..."
                value={userKeyInput}
                onChange={(e) => setUserKeyInput(e.target.value)}
                className="flex-1 bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono text-slate-800 outline-none focus:border-blue-500"
              />
              <button
                onClick={() => userKeyInput.trim() && setActiveApiKey(userKeyInput.trim())}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`relative w-full h-full flex flex-col flex-1 overflow-hidden bg-slate-100 select-none ${
        isFullscreen ? 'fixed inset-0 z-50 bg-white' : ''
      }`}
    >
      <APIProvider
        apiKey={activeApiKey}
        libraries={['marker', 'geometry']}
        onError={(err) => {
          console.error('APIProvider load error:', err);
          setMapError('Failed to load Google Maps JavaScript API script. Please check network connectivity or API key restrictions.');
        }}
      >
        {/* Auth or Loading Error Banner if Google Maps returns error */}
        {mapError && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-red-50 text-red-900 border border-red-300 px-4 py-2.5 rounded-xl text-xs shadow-xl flex items-center gap-3 max-w-lg">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <div className="flex-1 text-[11px] leading-relaxed">
              <strong className="block text-red-950 font-semibold">Map Notice:</strong>
              {mapError}
            </div>
            <button
              onClick={() => setMapError(null)}
              className="px-2.5 py-1 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-semibold cursor-pointer shrink-0"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Standard Mode Floating Overlays (Hidden in simpleMode) */}
        {!simpleMode && (
          <div className="absolute top-3 left-3 right-3 z-20 flex flex-wrap items-center justify-between pointer-events-none gap-2">
            {/* Top-Left: Clean Search Box */}
            <div className="pointer-events-auto relative w-56 sm:w-64 shadow-md rounded-xl">
              <div className="flex items-center bg-white/95 backdrop-blur-md border border-slate-200/90 rounded-xl px-3 py-1.5 text-xs text-slate-800 shadow-xs">
                <Search className="w-3.5 h-3.5 text-slate-400 mr-2 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search street, school, tank..."
                  className="w-full bg-transparent border-none outline-none text-slate-800 placeholder-slate-400 text-xs"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="text-slate-400 hover:text-slate-600 ml-1 p-0.5 cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>

              {/* Autocomplete Dropdown */}
              {searchResults.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden z-30 divide-y divide-slate-100 text-xs text-slate-700">
                  {searchResults.map((item) => (
                    <SearchItemButton
                      key={item.id}
                      item={item}
                      onSelect={() => setSearchQuery('')}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Top-Right: Roadmap/Satellite switch, Layer Toggles, Fit Village, Locate Buildings, Fullscreen */}
            <div className="pointer-events-auto flex items-center flex-wrap gap-1.5">
              {/* Layer Toggles */}
              <div className="bg-white/95 backdrop-blur-md border border-slate-200/90 rounded-xl p-1 shadow-md flex items-center gap-1 text-[11px] font-medium text-slate-700">
                <button
                  onClick={() => toggleLayer('floodExtent')}
                  className={`px-2 py-1 rounded-lg flex items-center gap-1 transition-all cursor-pointer ${
                    visibleLayers.floodExtent
                      ? 'bg-blue-600 text-white font-semibold shadow-xs'
                      : 'text-slate-500 hover:bg-slate-100 opacity-60'
                  }`}
                  title="Toggle Simulated Flood Depth Zones"
                >
                  <Waves className="w-3.5 h-3.5" />
                  <span>Flood</span>
                </button>

                <button
                  onClick={() => toggleLayer('buildings')}
                  className={`px-2 py-1 rounded-lg flex items-center gap-1 transition-all cursor-pointer ${
                    visibleLayers.buildings
                      ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                      : 'text-slate-500 hover:bg-slate-100 opacity-60'
                  }`}
                  title="Toggle Building Footprints"
                >
                  <Building className="w-3.5 h-3.5" />
                  <span>Buildings</span>
                </button>

                <button
                  onClick={() => toggleLayer('roads')}
                  className={`px-2 py-1 rounded-lg flex items-center gap-1 transition-all cursor-pointer ${
                    visibleLayers.roads
                      ? 'bg-amber-600 text-white font-semibold shadow-xs'
                      : 'text-slate-500 hover:bg-slate-100 opacity-60'
                  }`}
                  title="Toggle Road Network"
                >
                  <Route className="w-3.5 h-3.5" />
                  <span>Roads</span>
                </button>

                <button
                  onClick={() => {
                    const next = !(visibleLayers.drainageExisting || visibleLayers.drainageProposed);
                    setVisibleLayers((prev) => ({
                      ...prev,
                      drainageExisting: next,
                      drainageProposed: next,
                    }));
                  }}
                  className={`px-2 py-1 rounded-lg flex items-center gap-1 transition-all cursor-pointer ${
                    visibleLayers.drainageExisting || visibleLayers.drainageProposed
                      ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                      : 'text-slate-500 hover:bg-slate-100 opacity-60'
                  }`}
                  title="Toggle Drainage Channels"
                >
                  <Droplets className="w-3.5 h-3.5" />
                  <span>Drains</span>
                </button>

                <button
                  onClick={() => toggleLayer('earthquakes')}
                  className={`px-2 py-1 rounded-lg flex items-center gap-1 transition-all cursor-pointer ${
                    visibleLayers.earthquakes
                      ? 'bg-rose-600 text-white font-semibold shadow-xs'
                      : 'text-slate-500 hover:bg-slate-100 opacity-60'
                  }`}
                  title="Toggle Live USGS Recorded Earthquake Markers"
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>Quakes{earthquakes.length > 0 ? ` (${earthquakes.length})` : ''}</span>
                </button>
              </div>

              {/* Roadmap / Satellite Toggle */}
              <div className="bg-white/95 border border-slate-200/90 rounded-xl p-1 shadow-md backdrop-blur-md flex items-center gap-1 text-xs font-semibold text-slate-700">
                <button
                  onClick={() => setMapType('roadmap')}
                  className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                    mapType === 'roadmap'
                      ? 'bg-slate-800 text-white shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  Map
                </button>
                <button
                  onClick={() => setMapType('satellite')}
                  className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                    mapType === 'satellite'
                      ? 'bg-slate-800 text-white shadow-xs font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  Satellite
                </button>
              </div>

              {/* Fit Village & Locate Buildings Buttons */}
              <button
                onClick={() => {
                  if (onFitVillage) onFitVillage();
                  else setInternalCameraAction({ type: 'fit_village', timestamp: Date.now() });
                }}
                className="bg-white/95 text-slate-700 hover:text-blue-700 border border-slate-200/90 px-2.5 py-1.5 rounded-xl text-xs font-semibold shadow-md backdrop-blur-md flex items-center gap-1.5 transition-all cursor-pointer hover:bg-slate-50"
                title="Zoom to Verified Village Boundary"
              >
                <Compass className="w-3.5 h-3.5 text-blue-600" />
                <span className="hidden sm:inline">Fit Village</span>
              </button>

              <button
                onClick={() => {
                  if (onLocateBuildings) onLocateBuildings();
                  else setInternalCameraAction({ type: 'locate_buildings', timestamp: Date.now() });
                }}
                className="bg-white/95 text-slate-700 hover:text-indigo-700 border border-slate-200/90 px-2.5 py-1.5 rounded-xl text-xs font-semibold shadow-md backdrop-blur-md flex items-center gap-1.5 transition-all cursor-pointer hover:bg-slate-50"
                title="Zoom to Buildings & Houses (Zoom ~17-18)"
              >
                <Building2 className="w-3.5 h-3.5 text-indigo-600" />
                <span className="hidden sm:inline">Locate Buildings</span>
              </button>

              {/* Fullscreen Toggle */}
              <button
                onClick={() => setIsFullscreen(!isFullscreen)}
                className={`p-2 rounded-xl border text-xs font-medium shadow-md transition-all flex items-center gap-1 backdrop-blur-md cursor-pointer ${
                  isFullscreen
                    ? 'bg-blue-600 text-white border-blue-500'
                    : 'bg-white/95 text-slate-700 border-slate-200/90 hover:bg-slate-50'
                }`}
                title={isFullscreen ? 'Exit Fullscreen' : 'Maximize Map Viewport'}
              >
                {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        )}

        {/* Google Maps Full-Viewport Canvas - Centered at Verified Village with initial zoom 17.5 */}
        <div className="w-full h-full flex-1 relative min-h-[360px]">
          <Map
            mapId="DEMO_MAP_ID"
            defaultCenter={{ lat: dataset.center[1], lng: dataset.center[0] }}
            defaultZoom={17.5}
            gestureHandling="greedy"
            disableDefaultUI={true}
            internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
            className="w-full h-full"
          >
            {/* Basemap type synchronizer */}
            <MapTypeSynchronizer mapType={mapType} />

            {/* Camera Actions Handler (Fit Village, Locate Buildings, Pan to Village) */}
            <CameraActionHandler action={effectiveCameraAction} dataset={dataset} />

            {/* Overlays rendering & interactive click */}
            <GoogleMapOverlays
              dataset={dataset}
              activeFloodGeoJson={activeFloodGeoJson}
              visibleLayers={visibleLayers}
              onSelectFeature={onSelectFeature}
              activeHazardPolygons={activeHazardPolygons}
              smartInterventions={smartInterventions}
              onSelectIntervention={onSelectIntervention}
              earthquakes={earthquakes}
              selectedEarthquake={selectedEarthquake}
              onSelectEarthquake={onSelectEarthquake}
              isDrawingMode={isDrawingMode}
              drawingType={drawingType}
              onAddDrawnFeature={onAddDrawnFeature}
              proposedDrainsOverride={proposedDrainsOverride}
              proposedPondsOverride={proposedPondsOverride}
            />
          </Map>

          {/* Visible Loading Indicator */}
          <MapLoadingBadge />
        </div>

        {/* Floating Bottom-Left: Map Legend (Collapsed by default, hidden in simpleMode) */}
        {!simpleMode && (
          <div className="absolute bottom-3 left-3 z-20 pointer-events-auto bg-white/95 backdrop-blur-md border border-slate-200/90 rounded-2xl shadow-xl overflow-hidden text-xs max-w-xs sm:w-76 text-slate-800 transition-all">
            <div
              onClick={() => setLegendExpanded(!legendExpanded)}
              className="p-2.5 flex items-center justify-between font-bold text-slate-900 cursor-pointer bg-slate-50/80 border-b border-slate-100"
            >
              <div className="flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-blue-600" />
                <span>Map Legend & Layers</span>
              </div>
              {legendExpanded ? (
                <ChevronDown className="w-4 h-4 text-slate-400" />
              ) : (
                <ChevronUp className="w-4 h-4 text-slate-400" />
              )}
            </div>

            {legendExpanded && (
              <div className="p-3 space-y-2 max-h-[240px] overflow-y-auto pr-2 text-slate-600 text-[11px]">
                <div className="pb-1.5 border-b border-slate-100">
                  <div className="font-semibold text-slate-800 mb-1">Flood Water Depth:</div>
                  <div className="grid grid-cols-3 gap-1 text-[10px] text-center font-medium">
                    <div className="bg-blue-100 border border-blue-200 text-blue-800 py-0.5 rounded">0.05–0.2m</div>
                    <div className="bg-amber-100 border border-amber-200 text-amber-800 py-0.5 rounded">0.2–0.5m</div>
                    <div className="bg-red-100 border border-red-200 text-red-800 py-0.5 rounded">&gt;0.5m</div>
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <div className="w-3.5 h-3.5 bg-slate-700 rounded-xs"></div>
                    <span>Houses & Buildings (27 surveyed footprints)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-1 bg-amber-500 rounded"></div>
                    <span>Village Road Corridors</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-1 bg-emerald-600 rounded"></div>
                    <span>Existing Drainage Line</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Selected Feature Inspector Card */}
        {selectedFeature && (
          <div className="absolute top-3 left-3 z-30 w-72 sm:w-80 bg-white/95 backdrop-blur-md border border-slate-200 rounded-xl shadow-xl p-3 text-xs text-slate-800 animate-in fade-in slide-in-from-top-2 duration-150">
            <div className="flex items-start justify-between pb-2 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                    {selectedFeature.category.replace('_', ' ')}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">
                    ID: {selectedFeature.properties.id || 'N/A'}
                  </span>
                </div>
                <h3 className="font-bold text-slate-900 text-sm mt-1">
                  {selectedFeature.properties.name}
                </h3>
              </div>
              <button
                onClick={() => onSelectFeature && onSelectFeature(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-2 space-y-1 text-[11px]">
              {selectedFeature.coordinates && (
                <div className="flex justify-between py-0.5 border-b border-slate-50">
                  <span className="text-slate-500">Coordinates:</span>
                  <span className="font-mono text-slate-700">
                    {selectedFeature.coordinates[1].toFixed(5)}°N, {selectedFeature.coordinates[0].toFixed(5)}°E
                  </span>
                </div>
              )}

              {selectedFeature.category === 'building' && (
                <>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Type / Usage:</span>
                    <span className="font-semibold text-slate-800 capitalize">
                      {selectedFeature.properties.type}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Ground Elevation:</span>
                    <span className="font-semibold text-slate-800">
                      {selectedFeature.properties.groundElevation_m} m AMSL
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Plinth Clearance:</span>
                    <span className="font-semibold text-emerald-600">
                      +{selectedFeature.properties.plinthHeight_cm} cm
                    </span>
                  </div>
                  {selectedFeature.properties.occupants && (
                    <div className="flex justify-between py-0.5 border-b border-slate-50">
                      <span className="text-slate-500">Occupancy:</span>
                      <span className="font-semibold text-slate-800">
                        {selectedFeature.properties.occupants} people
                      </span>
                    </div>
                  )}
                </>
              )}

              {selectedFeature.category === 'road' && (
                <>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Road Type:</span>
                    <span className="font-semibold text-slate-800">
                      {selectedFeature.properties.roadType}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Length:</span>
                    <span className="font-semibold text-slate-800">
                      {selectedFeature.properties.length_m} meters
                    </span>
                  </div>
                </>
              )}

              {selectedFeature.category === 'flood_inundation' && (
                <>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Water Depth:</span>
                    <span className="font-semibold text-blue-600">
                      {selectedFeature.properties.waterDepth_m} m ({Math.round(selectedFeature.properties.waterDepth_m * 100)} cm)
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 mt-1 italic bg-slate-50 p-1.5 rounded">
                    {selectedFeature.properties.description}
                  </p>
                </>
              )}

              {selectedFeature.category === 'hazard_zone' && (
                <>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Hazard & Severity:</span>
                    <span className="font-bold text-red-600 uppercase">
                      {selectedFeature.properties.hazardType} · {selectedFeature.properties.riskLevel.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Intensity Metric:</span>
                    <span className="font-semibold text-slate-800">
                      {selectedFeature.properties.intensityLabel}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-600 mt-1 bg-red-50/60 border border-red-100 p-1.5 rounded">
                    {selectedFeature.properties.description}
                  </p>
                </>
              )}

              {selectedFeature.category === 'smart_intervention' && (
                <>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Estimated Outlay:</span>
                    <span className="font-bold text-blue-700">
                      ₹{selectedFeature.properties.estimatedCostLakhs} Lakhs
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Protected Population:</span>
                    <span className="font-semibold text-emerald-700">
                      {selectedFeature.properties.populationProtected?.toLocaleString()} residents
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Risk Reduction:</span>
                    <span className="font-semibold text-purple-700">
                      -{selectedFeature.properties.riskReductionPercent}% Vulnerability
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-600 mt-1 bg-blue-50/60 border border-blue-100 p-1.5 rounded">
                    {selectedFeature.properties.description}
                  </p>
                </>
              )}

              {selectedFeature.category === 'earthquake' && (
                <>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Recorded Magnitude:</span>
                    <span className="font-bold text-red-600">
                      M {selectedFeature.properties.mag?.toFixed(1)} ({selectedFeature.properties.magType?.toUpperCase() || 'Mw'})
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Focal Depth:</span>
                    <span className="font-semibold text-slate-800">
                      {selectedFeature.properties.depthKm} km
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Distance from Village:</span>
                    <span className="font-semibold text-blue-700">
                      {selectedFeature.properties.distanceKm !== null && selectedFeature.properties.distanceKm !== undefined
                        ? `${selectedFeature.properties.distanceKm} km`
                        : 'Coordinates needed'}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Recorded Time:</span>
                    <span className="font-medium text-slate-700">
                      {new Date(selectedFeature.properties.time).toLocaleString('en-IN', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5 border-b border-slate-50">
                    <span className="text-slate-500">Source:</span>
                    <span className="font-medium text-slate-700">
                      USGS Earthquake Hazards Program
                    </span>
                  </div>
                  {selectedFeature.properties.url && (
                    <div className="pt-1.5 flex justify-end">
                      <a
                        href={selectedFeature.properties.url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 hover:underline"
                      >
                        <span>USGS Event #{selectedFeature.properties.id}</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    </div>
                  )}
                  <p className="text-[10px] text-amber-900 mt-1 italic bg-amber-50 border border-amber-200/80 p-1.5 rounded">
                    Scientific Fact: Earthquakes cannot be predicted. Real instrumental observation.
                  </p>
                </>
              )}
            </div>
          </div>
        )}
      </APIProvider>
    </div>
  );
};

// Subcomponent: Synchronizes Google Maps basemap type reliably
const MapTypeSynchronizer: React.FC<{ mapType: 'roadmap' | 'satellite' }> = ({ mapType }) => {
  const map = useMap();

  useEffect(() => {
    if (!map) return;
    if (mapType === 'satellite') {
      // In Google Maps JS API, HYBRID provides satellite imagery WITH road names and labels
      map.setMapTypeId(google.maps.MapTypeId.HYBRID);
    } else {
      map.setMapTypeId(google.maps.MapTypeId.ROADMAP);
    }
  }, [map, mapType]);

  return null;
};

// Subcomponent: Handles Camera movements (Fit Village, Locate Buildings, Re-center)
const CameraActionHandler: React.FC<{
  action?: VillageMapCameraAction;
  dataset: VillageDataset;
}> = ({ action, dataset }) => {
  const map = useMap();

  // On dataset change or initial load: center on verified village at zoom ~17.5
  useEffect(() => {
    if (!map) return;
    map.panTo({ lat: dataset.center[1], lng: dataset.center[0] });
    map.setZoom(17.5);
  }, [map, dataset.center[0], dataset.center[1]]);

  // On explicit button triggers: Fit Village or Locate Buildings
  useEffect(() => {
    if (!map || !action) return;

    if (action.type === 'fit_village') {
      const bounds = new google.maps.LatLngBounds();
      const ring = dataset.boundary.features[0]?.geometry.coordinates[0];
      if (ring) {
        ring.forEach(([lng, lat]) => {
          bounds.extend({ lat, lng });
        });
        map.fitBounds(bounds, 40);
      }
    } else if (action.type === 'locate_buildings') {
      const bounds = new google.maps.LatLngBounds();
      let hasCoords = false;
      dataset.buildings.features.forEach((bld) => {
        bld.geometry.coordinates[0].forEach(([lng, lat]) => {
          bounds.extend({ lat, lng });
          hasCoords = true;
        });
      });
      if (hasCoords) {
        map.fitBounds(bounds, 50);
        // Ensure zoom is at level 17.5–18 so individual houses and local streets are clearly visible
        google.maps.event.addListenerOnce(map, 'idle', () => {
          const z = map.getZoom();
          if (z && z < 17) {
            map.setZoom(17.5);
          }
        });
      }
    } else if (action.type === 'recenter') {
      map.panTo({ lat: dataset.center[1], lng: dataset.center[0] });
      map.setZoom(17.5);
    }
  }, [map, action?.type, action?.timestamp, dataset]);

  return null;
};

// Subcomponent: Visible Map loading state indicator
const MapLoadingBadge: React.FC = () => {
  const map = useMap();
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (map) {
      const listener = google.maps.event.addListenerOnce(map, 'idle', () => {
        setLoaded(true);
      });
      const timer = setTimeout(() => setLoaded(true), 1200);
      return () => {
        google.maps.event.removeListener(listener);
        clearTimeout(timer);
      };
    }
  }, [map]);

  if (loaded) return null;

  return (
    <div className="absolute inset-0 z-10 bg-slate-900/20 backdrop-blur-2xs flex items-center justify-center text-slate-800 pointer-events-none transition-opacity duration-300">
      <div className="bg-white/95 border border-slate-200 px-4 py-2.5 rounded-xl shadow-lg flex items-center gap-2.5 text-xs text-slate-700">
        <Loader2 className="w-4 h-4 text-blue-600 animate-spin shrink-0" />
        <span className="font-semibold text-slate-900">Loading Google Maps...</span>
      </div>
    </div>
  );
};

// Subcomponent: Search result item with panTo
const SearchItemButton: React.FC<{
  item: { id: string; name: string; type: string; coords: { lat: number; lng: number } };
  onSelect: () => void;
}> = ({ item, onSelect }) => {
  const map = useMap();
  return (
    <button
      onClick={() => {
        if (map) {
          map.panTo(item.coords);
          map.setZoom(18);
        }
        onSelect();
      }}
      className="w-full text-left px-3 py-2 hover:bg-blue-50 flex items-center justify-between transition-colors cursor-pointer"
    >
      <div className="flex items-center gap-2 min-w-0 pr-2">
        <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0" />
        <span className="font-semibold text-slate-800 truncate">{item.name}</span>
      </div>
      <span className="text-[10px] text-slate-500 uppercase px-1.5 py-0.5 bg-slate-100 rounded ml-2 shrink-0 font-medium">
        {item.type}
      </span>
    </button>
  );
};

// Subcomponent: Overlays manager using Google Maps API objects
interface GoogleMapOverlaysProps {
  dataset: VillageDataset;
  activeFloodGeoJson?: FeatureCollection<Polygon, { depth_m: number; category: string }>;
  visibleLayers: Record<string, boolean>;
  onSelectFeature?: (feature: any | null) => void;
  activeHazardPolygons?: FeatureCollection<Polygon, any>;
  smartInterventions?: InfrastructureIntervention[];
  onSelectIntervention?: (intervention: InfrastructureIntervention) => void;
  earthquakes?: EarthquakeEvent[];
  selectedEarthquake?: EarthquakeEvent | null;
  onSelectEarthquake?: (eq: EarthquakeEvent) => void;
  isDrawingMode?: boolean;
  drawingType?: 'drain' | 'retention';
  onAddDrawnFeature?: (coordinates: [number, number][], type: 'drain' | 'retention') => void;
  proposedDrainsOverride?: FeatureCollection<LineString, DrainageProperties>;
  proposedPondsOverride?: FeatureCollection<Polygon, RetentionPondProperties>;
}

const GoogleMapOverlays: React.FC<GoogleMapOverlaysProps> = ({
  dataset,
  activeFloodGeoJson,
  visibleLayers,
  onSelectFeature = () => {},
  activeHazardPolygons,
  smartInterventions = [],
  onSelectIntervention,
  earthquakes = [],
  selectedEarthquake = null,
  onSelectEarthquake,
  isDrawingMode = false,
  proposedDrainsOverride,
  proposedPondsOverride,
}) => {
  const map = useMap();

  const boundaryPolyRef = useRef<google.maps.Polygon | null>(null);
  const waterPolysRef = useRef<google.maps.Polygon[]>([]);
  const retentionPolysRef = useRef<google.maps.Polygon[]>([]);
  const roadLinesRef = useRef<google.maps.Polyline[]>([]);
  const drainLinesRef = useRef<google.maps.Polyline[]>([]);
  const buildingPolysRef = useRef<google.maps.Polygon[]>([]);
  const floodPolysRef = useRef<google.maps.Polygon[]>([]);
  const hazardPolysRef = useRef<google.maps.Polygon[]>([]);
  const interventionMarkersRef = useRef<google.maps.Marker[]>([]);
  const earthquakeMarkersRef = useRef<google.maps.Marker[]>([]);

  // 1. Village Boundary Polygon (WGS84 [lng, lat] -> Google Maps {lat, lng})
  useEffect(() => {
    if (!map) return;
    if (boundaryPolyRef.current) boundaryPolyRef.current.setMap(null);

    if (visibleLayers.boundary && dataset.boundary.features.length > 0) {
      const ring = dataset.boundary.features[0].geometry.coordinates[0];
      const coords = ring.map(([lng, lat]) => ({ lat, lng }));

      const poly = new google.maps.Polygon({
        paths: coords,
        strokeColor: '#2563eb',
        strokeOpacity: 0.85,
        strokeWeight: 2,
        fillColor: '#3b82f6',
        fillOpacity: 0.04,
        zIndex: 1,
        map,
      });

      poly.addListener('click', (e: google.maps.MapMouseEvent) => {
        onSelectFeature({
          category: 'boundary',
          properties: dataset.boundary.features[0].properties,
          geometry: dataset.boundary.features[0].geometry,
          coordinates: e.latLng ? [e.latLng.lng(), e.latLng.lat()] : undefined,
        });
      });

      boundaryPolyRef.current = poly;
    }

    return () => {
      if (boundaryPolyRef.current) boundaryPolyRef.current.setMap(null);
    };
  }, [map, dataset.boundary, visibleLayers.boundary]);

  // 2. Natural Water Bodies (Ponds, Tanks, Streams)
  useEffect(() => {
    if (!map) return;
    waterPolysRef.current.forEach((p) => p.setMap(null));
    waterPolysRef.current = [];

    if (visibleLayers.waterBodies) {
      dataset.waterBodies.features.forEach((wb) => {
        const coords = wb.geometry.coordinates[0].map(([lng, lat]) => ({ lat, lng }));

        const poly = new google.maps.Polygon({
          paths: coords,
          strokeColor: '#0284c7',
          strokeOpacity: 0.9,
          strokeWeight: 1.5,
          fillColor: '#0ea5e9',
          fillOpacity: 0.35,
          zIndex: 3,
          map,
        });

        poly.addListener('click', (e: google.maps.MapMouseEvent) => {
          onSelectFeature({
            category: 'water_body',
            properties: wb.properties,
            geometry: wb.geometry,
            coordinates: e.latLng ? [e.latLng.lng(), e.latLng.lat()] : undefined,
          });
        });

        waterPolysRef.current.push(poly);
      });
    }

    return () => {
      waterPolysRef.current.forEach((p) => p.setMap(null));
    };
  }, [map, dataset.waterBodies, visibleLayers.waterBodies]);

  // 3. Retention Basins / Ponds
  useEffect(() => {
    if (!map) return;
    retentionPolysRef.current.forEach((p) => p.setMap(null));
    retentionPolysRef.current = [];

    if (visibleLayers.retentionPonds) {
      const activePonds = proposedPondsOverride || dataset.retentionPonds;

      activePonds.features.forEach((rp) => {
        const coords = rp.geometry.coordinates[0].map(([lng, lat]) => ({ lat, lng }));

        const poly = new google.maps.Polygon({
          paths: coords,
          strokeColor: '#059669',
          strokeOpacity: 0.9,
          strokeWeight: 2,
          fillColor: '#10b981',
          fillOpacity: 0.3,
          zIndex: 3,
          map,
        });

        poly.addListener('click', (e: google.maps.MapMouseEvent) => {
          onSelectFeature({
            category: 'retention_pond',
            properties: rp.properties,
            geometry: rp.geometry,
            coordinates: e.latLng ? [e.latLng.lng(), e.latLng.lat()] : undefined,
          });
        });

        retentionPolysRef.current.push(poly);
      });
    }

    return () => {
      retentionPolysRef.current.forEach((p) => p.setMap(null));
    };
  }, [map, dataset.retentionPonds, proposedPondsOverride, visibleLayers.retentionPonds]);

  // 4. Roads Network
  useEffect(() => {
    if (!map) return;
    roadLinesRef.current.forEach((l) => l.setMap(null));
    roadLinesRef.current = [];

    if (visibleLayers.roads) {
      dataset.roads.features.forEach((rd) => {
        const coords = rd.geometry.coordinates.map(([lng, lat]) => ({ lat, lng }));
        const color =
          rd.properties.roadType === 'State Highway'
            ? '#ea580c'
            : rd.properties.roadType === 'Panchayat Arterial'
            ? '#f59e0b'
            : rd.properties.roadType === 'Canal Bund'
            ? '#10b981'
            : '#64748b';

        const line = new google.maps.Polyline({
          path: coords,
          strokeColor: color,
          strokeOpacity: 0.95,
          strokeWeight: 3.5,
          zIndex: 5,
          map,
        });

        line.addListener('click', (e: google.maps.MapMouseEvent) => {
          onSelectFeature({
            category: 'road',
            properties: rd.properties,
            geometry: rd.geometry,
            coordinates: e.latLng ? [e.latLng.lng(), e.latLng.lat()] : undefined,
          });
        });

        roadLinesRef.current.push(line);
      });
    }

    return () => {
      roadLinesRef.current.forEach((l) => l.setMap(null));
    };
  }, [map, dataset.roads, visibleLayers.roads]);

  // 5. Drainage Lines (Solid emerald for existing, dashed violet for proposed)
  useEffect(() => {
    if (!map) return;
    drainLinesRef.current.forEach((l) => l.setMap(null));
    drainLinesRef.current = [];

    const activeDrains = proposedDrainsOverride || dataset.drainageLines;

    activeDrains.features.forEach((dr) => {
      const isProposed = dr.properties.status === 'proposed';
      if (isProposed && !visibleLayers.drainageProposed) return;
      if (!isProposed && !visibleLayers.drainageExisting) return;

      const coords = dr.geometry.coordinates.map(([lng, lat]) => ({ lat, lng }));

      const line = new google.maps.Polyline({
        path: coords,
        strokeColor: isProposed ? '#9333ea' : '#059669',
        strokeOpacity: 0.95,
        strokeWeight: 3.5,
        zIndex: 6,
        map,
      });

      line.addListener('click', (e: google.maps.MapMouseEvent) => {
        onSelectFeature({
          category: 'drainage',
          properties: dr.properties,
          geometry: dr.geometry,
          coordinates: e.latLng ? [e.latLng.lng(), e.latLng.lat()] : undefined,
        });
      });

      drainLinesRef.current.push(line);
    });

    return () => {
      drainLinesRef.current.forEach((l) => l.setMap(null));
    };
  }, [map, dataset.drainageLines, proposedDrainsOverride, visibleLayers.drainageExisting, visibleLayers.drainageProposed]);

  // 6. Buildings Footprints & Plinths: Rendered as actual individual polygons (NOT generic square pins)
  useEffect(() => {
    if (!map) return;
    buildingPolysRef.current.forEach((p) => p.setMap(null));
    buildingPolysRef.current = [];

    if (visibleLayers.buildings) {
      dataset.buildings.features.forEach((bld) => {
        // GeoJSON [longitude, latitude] -> Google Maps { lat, lng }
        const coords = bld.geometry.coordinates[0].map(([lng, lat]) => ({ lat, lng }));
        
        const isCritical = ['school', 'clinic', 'panchayat', 'water_facility'].includes(bld.properties.type);
        const color =
          bld.properties.type === 'school'
            ? '#4f46e5'
            : bld.properties.type === 'clinic'
            ? '#ef4444'
            : bld.properties.type === 'panchayat'
            ? '#d97706'
            : bld.properties.type === 'water_facility'
            ? '#0284c7'
            : bld.properties.type === 'agriculture'
            ? '#16a34a'
            : bld.properties.type === 'religious'
            ? '#9333ea'
            : bld.properties.type === 'commercial'
            ? '#ea580c'
            : '#475569'; // Residential houses: slate roof

        const strokeColor = isCritical ? '#0f172a' : '#1e293b';

        // Polygon footprint representing individual structure
        const poly = new google.maps.Polygon({
          paths: coords,
          strokeColor,
          strokeOpacity: 0.95,
          strokeWeight: isCritical ? 2 : 1.5,
          fillColor: color,
          fillOpacity: 0.85,
          zIndex: 10, // Strictly above flood polygons (zIndex: 2)
          map,
        });

        poly.addListener('click', (e: google.maps.MapMouseEvent) => {
          onSelectFeature({
            category: 'building',
            properties: bld.properties,
            geometry: bld.geometry,
            coordinates: e.latLng ? [e.latLng.lng(), e.latLng.lat()] : undefined,
          });
        });

        buildingPolysRef.current.push(poly);
      });
    }

    return () => {
      buildingPolysRef.current.forEach((p) => p.setMap(null));
    };
  }, [map, dataset.buildings, visibleLayers.buildings]);

  // 7. Simulated Flood Water Depth Overlays: Transparent so road names and satellite houses remain visible
  useEffect(() => {
    if (!map) return;
    floodPolysRef.current.forEach((p) => p.setMap(null));
    floodPolysRef.current = [];

    if (visibleLayers.floodExtent && activeFloodGeoJson && activeFloodGeoJson.features) {
      activeFloodGeoJson.features.forEach((feat) => {
        // GeoJSON [longitude, latitude] -> Google Maps { lat, lng }
        const coords = feat.geometry.coordinates[0].map(([lng, lat]) => ({ lat, lng }));
        
        const isSevere = feat.properties.category === 'severe';
        const isModerate = feat.properties.category === 'moderate';
        
        const color = isSevere ? '#dc2626' : isModerate ? '#f59e0b' : '#2563eb';
        const strokeColor = isSevere ? '#b91c1c' : isModerate ? '#d97706' : '#1d4ed8';

        // Transparent shading: low fill opacity so roads and buildings stay visible underneath
        const poly = new google.maps.Polygon({
          paths: coords,
          strokeColor,
          strokeOpacity: 0.5,
          strokeWeight: 1.5,
          fillColor: color,
          fillOpacity: isSevere ? 0.24 : isModerate ? 0.18 : 0.14,
          zIndex: 2, // Sits beneath buildings (zIndex: 10) and roads (zIndex: 5)
          map,
        });

        poly.addListener('click', (e: google.maps.MapMouseEvent) => {
          onSelectFeature({
            category: 'flood_inundation',
            properties: {
              name: `Simulated Inundation Zone (${feat.properties.category.toUpperCase()})`,
              waterDepth_m: feat.properties.depth_m,
              description: `Peak simulated water depth: ${feat.properties.depth_m}m (${Math.round(
                feat.properties.depth_m * 100
              )} cm). Ingress risk depends on local building plinth heights.`,
            },
            coordinates: e.latLng ? [e.latLng.lng(), e.latLng.lat()] : undefined,
          });
        });

        floodPolysRef.current.push(poly);
      });
    }

    return () => {
      floodPolysRef.current.forEach((p) => p.setMap(null));
    };
  }, [map, activeFloodGeoJson, visibleLayers.floodExtent]);

  // 8. Active Hazard Risk Polygons (Multi-Hazard Risk Layer)
  useEffect(() => {
    if (!map) return;
    hazardPolysRef.current.forEach((p) => p.setMap(null));
    hazardPolysRef.current = [];

    if (activeHazardPolygons && activeHazardPolygons.features) {
      activeHazardPolygons.features.forEach((feat) => {
        const coords = feat.geometry.coordinates[0].map(([lng, lat]) => ({ lat, lng }));
        const level = feat.properties.riskLevel;
        const color =
          level === 'very_high'
            ? '#ef4444'
            : level === 'high'
            ? '#f97316'
            : level === 'moderate'
            ? '#eab308'
            : '#10b981';
        const strokeColor =
          level === 'very_high'
            ? '#dc2626'
            : level === 'high'
            ? '#c2410c'
            : level === 'moderate'
            ? '#a16207'
            : '#047857';

        const poly = new google.maps.Polygon({
          paths: coords,
          strokeColor,
          strokeOpacity: 0.85,
          strokeWeight: 1.5,
          fillColor: color,
          fillOpacity: level === 'very_high' ? 0.28 : level === 'high' ? 0.22 : level === 'moderate' ? 0.18 : 0.14,
          zIndex: 4,
          map,
        });

        poly.addListener('click', (e: google.maps.MapMouseEvent) => {
          onSelectFeature({
            category: 'hazard_zone',
            properties: {
              name: feat.properties.zoneName,
              hazardType: feat.properties.hazardType,
              riskLevel: feat.properties.riskLevel,
              intensityLabel: feat.properties.intensityLabel,
              description: feat.properties.description,
            },
            coordinates: e.latLng ? [e.latLng.lng(), e.latLng.lat()] : undefined,
          });
        });

        hazardPolysRef.current.push(poly);
      });
    }

    return () => {
      hazardPolysRef.current.forEach((p) => p.setMap(null));
    };
  }, [map, activeHazardPolygons]);

  // 9. Smart Infrastructure Interventions Markers
  useEffect(() => {
    if (!map) return;
    interventionMarkersRef.current.forEach((m) => m.setMap(null));
    interventionMarkersRef.current = [];

    if (smartInterventions && smartInterventions.length > 0) {
      smartInterventions.forEach((item) => {
        if (!item.isEnabled) return;
        const [lng, lat] = item.location;

        const pinSvg = `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
          <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="#2563eb" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 2a8 8 0 0 0-8 8c0 5.25 8 12 8 12s8-6.75 8-12a8 8 0 0 0-8-8z"/>
            <circle cx="12" cy="10" r="3" fill="#ffffff"/>
          </svg>
        `)}`;

        const marker = new google.maps.Marker({
          position: { lat, lng },
          map,
          title: item.name,
          icon: {
            url: pinSvg,
            scaledSize: new google.maps.Size(26, 26),
            anchor: new google.maps.Point(13, 26),
          },
          zIndex: 25,
        });

        marker.addListener('click', () => {
          onSelectFeature({
            category: 'smart_intervention',
            properties: item,
            coordinates: [lng, lat],
          });
          if (onSelectIntervention) onSelectIntervention(item);
        });

        interventionMarkersRef.current.push(marker);
      });
    }

    return () => {
      interventionMarkersRef.current.forEach((m) => m.setMap(null));
    };
  }, [map, smartInterventions]);

  // 10. Real USGS Earthquake Markers
  useEffect(() => {
    if (!map) return;
    earthquakeMarkersRef.current.forEach((m) => m.setMap(null));
    earthquakeMarkersRef.current = [];

    if (visibleLayers.earthquakes && earthquakes && earthquakes.length > 0) {
      earthquakes.forEach((eq) => {
        const lat = eq.latitude;
        const lng = eq.longitude;
        if (isNaN(lat) || isNaN(lng)) return;

        // Color and sizing scaled by recorded magnitude
        const color = eq.mag >= 6.0 ? '#dc2626' : (eq.mag >= 4.5 ? '#ea580c' : (eq.mag >= 3.0 ? '#d97706' : '#059669'));
        const size = Math.max(22, Math.min(36, Math.round(eq.mag * 5.5)));

        const seismicSvg = `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
          <svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" fill="${color}" fill-opacity="0.88" stroke="#ffffff" stroke-width="2"/>
            <path d="M4 12h4l2-4 4 8 2-4h4" fill="none" stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        `)}`;

        const marker = new google.maps.Marker({
          position: { lat, lng },
          map,
          title: `M ${eq.mag.toFixed(1)} - ${eq.place} (Depth: ${eq.depthKm} km)`,
          icon: {
            url: seismicSvg,
            scaledSize: new google.maps.Size(size, size),
            anchor: new google.maps.Point(size / 2, size / 2),
          },
          zIndex: 35,
        });

        marker.addListener('click', () => {
          onSelectFeature({
            category: 'earthquake',
            properties: {
              ...eq,
              name: `M ${eq.mag.toFixed(1)} Earthquake — ${eq.place}`,
            },
            coordinates: [lng, lat],
          });
          if (onSelectEarthquake) onSelectEarthquake(eq);
        });

        earthquakeMarkersRef.current.push(marker);
      });
    }

    return () => {
      earthquakeMarkersRef.current.forEach((m) => m.setMap(null));
    };
  }, [map, earthquakes, visibleLayers.earthquakes]);

  // Center on selected earthquake when triggered
  useEffect(() => {
    if (!map || !selectedEarthquake) return;
    map.panTo({ lat: selectedEarthquake.latitude, lng: selectedEarthquake.longitude });
    map.setZoom(Math.max(map.getZoom() || 8, 8));
  }, [map, selectedEarthquake]);

  return null;
};
