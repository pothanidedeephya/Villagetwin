import React, { useState, useEffect, useRef } from 'react';
import { Search, MapPin, Loader2, Compass, X, Globe, Sparkles } from 'lucide-react';
import type { LocationSearchResult } from '../../types/nationwide';
import { searchIndiaLocations } from '../../services/geospatialService';
import { NATIONWIDE_BENCHMARK_LOCATIONS } from '../../data/indiaLocations';

interface NationwideLocationSearchProps {
  currentLocation: LocationSearchResult;
  onSelectLocation: (location: LocationSearchResult) => void;
  isLoadingData?: boolean;
}

export const NationwideLocationSearch: React.FC<NationwideLocationSearchProps> = ({
  currentLocation,
  onSelectLocation,
  isLoadingData = false,
}) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<LocationSearchResult[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Search debouncing
  useEffect(() => {
    if (!query.trim()) {
      setResults(NATIONWIDE_BENCHMARK_LOCATIONS);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      const items = await searchIndiaLocations(query);
      setResults(items);
      setIsSearching(false);
    }, 280);

    return () => clearTimeout(timer);
  }, [query]);

  const handleSelect = (loc: LocationSearchResult) => {
    onSelectLocation(loc);
    setQuery('');
    setIsOpen(false);
  };

  return (
    <div ref={wrapperRef} className="relative w-full max-w-xl">
      {/* Search Input Bar */}
      <div className="relative flex items-center">
        <div className="absolute left-3 text-slate-400 pointer-events-none">
          {isLoadingData ? (
            <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
          ) : (
            <Search className="w-4 h-4 text-slate-400" />
          )}
        </div>

        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => {
            setIsOpen(true);
            if (!query) setResults(NATIONWIDE_BENCHMARK_LOCATIONS);
          }}
          placeholder="Search any village, Gram Panchayat, district or state in India (e.g. Joshimath, Majuli, Pokhran, Kothuru)..."
          className="w-full pl-9 pr-8 py-2 text-xs bg-white text-slate-900 border border-slate-200 rounded-xl shadow-xs placeholder:text-slate-400 focus:outline-hidden focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all"
        />

        {query && (
          <button
            onClick={() => {
              setQuery('');
              setResults(NATIONWIDE_BENCHMARK_LOCATIONS);
            }}
            className="absolute right-2.5 text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Dropdown Results */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-xl z-50 overflow-hidden text-xs max-h-80 flex flex-col animate-in fade-in slide-in-from-top-1 duration-150">
          
          {/* Quick Region Benchmark Filter Strip */}
          <div className="p-2 bg-slate-50 border-b border-slate-100 flex items-center gap-1 overflow-x-auto scrollbar-none text-[10px] text-slate-500">
            <span className="font-semibold text-slate-600 uppercase px-1">Regions:</span>
            {NATIONWIDE_BENCHMARK_LOCATIONS.slice(0, 6).map((b) => (
              <button
                key={b.id}
                onClick={() => handleSelect(b)}
                className="px-2 py-0.5 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 whitespace-nowrap transition-colors cursor-pointer"
              >
                {b.name.split(' ')[0]} ({b.state})
              </button>
            ))}
          </div>

          {/* Results List */}
          <div className="overflow-y-auto flex-1 divide-y divide-slate-100">
            {isSearching ? (
              <div className="p-4 text-center text-slate-400 flex items-center justify-center gap-2">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" />
                <span>Searching nationwide gazetteer & coordinates...</span>
              </div>
            ) : results.length > 0 ? (
              results.map((loc) => {
                const isCurrent = loc.id === currentLocation.id;
                return (
                  <button
                    key={loc.id}
                    onClick={() => handleSelect(loc)}
                    className={`w-full text-left px-3.5 py-2.5 hover:bg-blue-50 flex items-start gap-2.5 transition-colors cursor-pointer ${
                      isCurrent ? 'bg-blue-50/60 font-medium' : ''
                    }`}
                  >
                    <MapPin className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-semibold text-slate-900 text-xs">{loc.name}</span>
                        <span className="text-[10px] uppercase font-mono px-1 py-0.2 rounded bg-slate-100 text-slate-600">
                          {loc.adminLevel.replace('_', ' ')}
                        </span>
                        <span className="text-[10px] text-slate-500 capitalize">
                          · {loc.regionCategory}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 truncate mt-0.5">
                        {loc.subdistrict ? `${loc.subdistrict}, ` : ''}{loc.district}, {loc.state}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        {loc.center[1].toFixed(4)}°N, {loc.center[0].toFixed(4)}°E · Elev: ~{loc.elevation_m || 25}m AMSL
                      </div>
                    </div>
                  </button>
                );
              })
            ) : (
              <div className="p-4 text-center text-slate-400">
                No matching Indian village, tehsil, or district found for "{query}".
                <div className="text-[11px] text-slate-500 mt-1">
                  Tip: You can also enter exact coordinates (e.g. <code>16.212, 80.842</code>).
                </div>
              </div>
            )}
          </div>

          {/* Footer note */}
          <div className="p-2 bg-slate-50 border-t border-slate-100 text-[10px] text-slate-500 text-center">
            Nationwide Gazetteer: Resolves villages, Gram Panchayats, tehsils, and coordinates across India.
          </div>
        </div>
      )}
    </div>
  );
};
